
from django.contrib import admin
from django.conf.urls import url
from django.conf import settings
from django.conf.urls.static import static
from legal.views import *


urlpatterns = [
    url('admin/', admin.site.urls),
    url(r'^$',index,name='index'),
    url(r'^test',test,name='test'),
    url(r'^delete', delete_db, name='delete'),
    url(r'^logout',signout,name='logout'),
    url(r'^dashboard',dashboard,name='dashboard'),
    url(r'^branch_add', branch_add, name='branch_add'),
    url(r'^branch_delete/(?P<id>\d+)$', branch_delete, name='branch_delete'),
    url(r'^user_add', user_add, name='user_add'),
    url(r'^user_list', user_list, name='user_list'),
    url(r'^panel_list', panel_list, name='panel_list'),
    url(r'^associate_list', associate_list, name='associate_list'),
    url(r'^user_edit/(?P<id>\d+)$', user_edit, name='user_edit'),
    url(r'^user_update/(?P<id>\d+)$', user_update, name='user_update'),
    url(r'^user_delete/(?P<id>\d+)$', user_delete, name='user_delete'),
    url(r'^enquiry_add', enquiry_add, name='enquiry_add'),
    url(r'^enquiry_list', enquiry_list, name='enquiry_list'),
    url(r'^enquiry_edit/(?P<id>\d+)$', enquiry_edit, name='enquiry_edit'),
    url(r'^enquiry_update/(?P<id>\d+)$', enquiry_update, name='enquiry_update'),
    url(r'^pending_list', pending_list, name='pending_list'),
    url(r'^recall_list', recall_list_today, name='recall_list'),
    url(r'^recall_update/(?P<id>\d+)$', recall_update, name='recall_update'),
    url(r'^pending_edit/(?P<id>\d+)$', pending_edit, name='pending_edit'),
    url(r'^pending_update/(?P<id>\d+)$', pending_update, name='pending_update'),
    url(r'^recall_edit/(?P<id>\d+)$', recall_edit, name='recall_edit'),
    url(r'^recall_today',recall_list,name='recall_today'),
    url(r'^sales_view',sale_list,name='sales_view'),
    url(r'^sales_edit/(?P<id>\d+)$', sale_edit, name='sale_edit'),
    url(r'^sales_update/(?P<id>\d+)$', sales_update, name='sales_update'),
    url(r'^kyc_add/(?P<id>\d+)$', kyc_add, name='kyc_add'),
    url(r'^kyc_list', kyc_list, name='kyc_list'),
    url(r'^kyc_edit/(?P<id>\d+)$', kyc_edit, name='kyc_edit'),
    url(r'^kyc_update/(?P<id>\d+)$', kyc_update, name='kyc_update'),
    url(r'^kyc_pending', kyc_pending_list, name='kyc_pending'),
    url(r'^kyc_p_edit/(?P<id>\d+)$', kyc_p_edit, name='kyc_p_edit'),
    url(r'^kyc_p_update/(?P<id>\d+)$', kyc_p_update, name='kyc_p_update'),
    url(r'^agent_add', agent_add, name='agent_add'),
    url(r'^agent_list', agent_list, name='agent_list'),
    url(r'^agent_edit/(?P<id>\d+)$', agent_edit, name='agent_edit'),
    url(r'^agent_update/(?P<id>\d+)$', agent_update, name='agent_update'),
    url(r'^legal_list', legal_list, name='legal_list'),
    url(r'^legal_edit/(?P<id>\d+)$', legal_edit, name='legal_edit'),
    url(r'^legal_update/(?P<id>\d+)$', legal_update, name='legal_update'),
    url(r'^legal_pending_list', legal_pending_list, name='legal_pending_list'),
    url(r'^legal_pending_edit/(?P<id>\d+)$', legal_pending_edit, name='legal_pending_edit'),
    url(r'^legal_pending_update/(?P<id>\d+)$', legal_pending_update, name='legal_pending_update'),
    url(r'^finance_list', finance_list, name='finance_list'),
    url(r'^finance_edit/(?P<id>\d+)$', finance_edit, name='finance_edit'),
    url(r'^finance_update/(?P<id>\d+)$', finance_update, name='finance_update'),
    url(r'^notice_list', notice_list, name='notice_list'),
    url(r'^notice_edit/(?P<id>\d+)$', notice_edit, name='notice_edit'),
    url(r'^notice_update/(?P<id>\d+)$', notice_update, name='notice_update'),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# handler404='legal.views.page404'
