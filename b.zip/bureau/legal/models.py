from django.db import models

account_status = (('Active','Active'),('Deactive','Deactive'))
account_state = (('Active','Active'),('Deactive','Deactive'))

class users(models.Model):

    name                =models.CharField(max_length=50,default='',null=True)
    branch              =models.CharField(max_length=50, default='',null=True)
    father_name         =models.CharField(max_length=50,default='',null=True)
    mother_name         =models.CharField(max_length=50,default='',null=True)
    mobile              =models.CharField(max_length=50,default='',null=True)
    alt_mobile          =models.CharField(max_length=50,default='',null=True)
    email               =models.CharField(max_length=50,default='',null=True)
    mar_status          =models.CharField(max_length=50,default='',null=True)
    blood               =models.CharField(max_length=50,default='',null=True)
    address             =models.CharField(max_length=250,default='',null=True)
    qualification       =models.CharField(max_length=50,default='',null=True)
    designation         =models.CharField(max_length=50,default='',null=True)
    dob                 =models.CharField(max_length=50,default='',null=True)
    pincode             =models.CharField(max_length=50,default='',null=True)
    photo               =models.ImageField(default='',null=True,upload_to='user_profile')
    account_level       =models.CharField(max_length=50,default='',null=True)
    staff_type          =models.CharField(max_length=50,default='',null=True)
    uid                 =models.CharField(max_length=50,default='',null=True)
    password            =models.CharField(max_length=50,default='',null=True)
    status              =models.CharField(choices=account_state , max_length=10, default='')

    def __str__(self):
        return self.name

class login_db(models.Model):
    account_level       = models.CharField(max_length=50, default='',null=True)
    name                = models.CharField(max_length=50,default='',null=True)
    uid                 = models.CharField(max_length=50, default='',null=True)
    password            = models.CharField(max_length=50, default='',null=True)
    branch              = models.CharField(max_length=50, default='',null=True)
    # status              = models.CharField(choices=account_status,max_length=10,default='')

    def __str__(self):
        return (self.name+'     :   '+self.uid)

class branch_db(models.Model):
    branch             = models.CharField(max_length=50, default='',null=True)
    def __str__(self):
        return self.branch

class enquiry(models.Model):
    enquiry_code        =models.CharField(max_length=15,default='',null=True)
    enquiry_name        =models.CharField(max_length=30,default='',null=True)
    branch              = models.CharField(max_length=50, default='',null=True)
    client_type         =models.CharField(max_length=15,default='',null=True)
    date                =models.CharField(max_length=15,default='',null=True)
    location            =models.CharField(max_length=50,default='',null=True)
    district            =models.CharField(max_length=50,default='',null=True)
    mobile              =models.CharField(max_length=50,default='',null=True)
    alt_mobile          =models.CharField(max_length=50,default='',null=True)
    case_type           =models.CharField(max_length=50,default='',null=True)
    new_type            =models.CharField(max_length=50,default='',null=True)
    case_nature         =models.CharField(max_length=500,default='',null=True)
    new_nature          =models.CharField(max_length=500,default='',null=True)
    reference           =models.CharField(max_length=500,default='',null=True)
    new_reference       =models.CharField(max_length=500,default='',null=True)
    refer_client        =models.CharField(max_length=500,default='',null=True)
    refer_agent         =models.CharField(max_length=500,default='',null=True)
    description         =models.CharField(max_length=1000,default='',null=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.enquiry_name

class closed(models.Model):
    enquiry_code        =models.CharField(max_length=15,default='',null=True)
    enquiry_name        =models.CharField(max_length=30,default='',null=True)
    branch = models.CharField(max_length=50, default='',null=True)
    client_type         =models.CharField(max_length=15,default='',null=True)
    date                =models.CharField(max_length=15,default='',null=True)
    location            =models.CharField(max_length=50,default='',null=True)
    district            =models.CharField(max_length=50,default='',null=True)
    mobile              =models.CharField(max_length=50,default='',null=True)
    alt_mobile          =models.CharField(max_length=50,default='',null=True)
    case_type           =models.CharField(max_length=50,default='',null=True)
    new_type            =models.CharField(max_length=50,default='',null=True)
    case_nature         =models.CharField(max_length=500,default='',null=True)
    new_nature          =models.CharField(max_length=500,default='',null=True)
    reference           =models.CharField(max_length=500,default='',null=True)
    new_reference       =models.CharField(max_length=500,default='',null=True)
    refer_client        =models.CharField(max_length=500,default='',null=True)
    refer_agent         =models.CharField(max_length=500,default='',null=True)
    description         =models.CharField(max_length=1000,default='',null=True)

    class Meta:
        ordering = ['-id']


    def __str__(self):
        return self.enquiry_name

class count(models.Model):
    name                =models.CharField(max_length=50,default='',null=True)

    def __str__(self):
        return self.name

class case_type(models.Model):
    new_case_type       =models.CharField(max_length=500,default='',null=True)
    new_case_nature     =models.CharField(max_length=500,default='',null=True)
    new_reference       =models.CharField(max_length=500,default='',null=True)
    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.new_case_type


class pending(models.Model):
    enquiry_code        = models.CharField(max_length=15, default='',null=True)
    enquiry_name        = models.CharField(max_length=30, default='',null=True)
    branch = models.CharField(max_length=50, default='',null=True)
    client_type         = models.CharField(max_length=15, default='',null=True)
    date                = models.CharField(max_length=15, default='',null=True)
    location            = models.CharField(max_length=50, default='',null=True)
    district            = models.CharField(max_length=50, default='',null=True)
    mobile              = models.CharField(max_length=50, default='',null=True)
    alt_mobile          = models.CharField(max_length=50, default='',null=True)
    case_type           = models.CharField(max_length=50, default='',null=True)
    new_type            = models.CharField(max_length=50, default='',null=True)
    case_nature         = models.CharField(max_length=500, default='',null=True)
    new_nature          = models.CharField(max_length=500, default='',null=True)
    reference           = models.CharField(max_length=500, default='',null=True)
    new_reference       = models.CharField(max_length=500, default='',null=True)
    refer_client        = models.CharField(max_length=500, default='',null=True)
    refer_agent         = models.CharField(max_length=500, default='',null=True)
    description         = models.CharField(max_length=1000, default='',null=True)
    class Meta:
        ordering = ['-id']


    def __str__(self):
        return self.enquiry_name


class recall(models.Model):
    enquiry_code        = models.CharField(max_length=15, default='',null=True)
    enquiry_name        = models.CharField(max_length=30, default='',null=True)
    branch              = models.CharField(max_length=50, default='',null=True)
    client_type         = models.CharField(max_length=15, default='',null=True)
    date                = models.CharField(max_length=15, default='',null=True)
    location            = models.CharField(max_length=50, default='',null=True)
    district            = models.CharField(max_length=50, default='',null=True)
    mobile              = models.CharField(max_length=50, default='',null=True)
    alt_mobile          = models.CharField(max_length=50, default='',null=True)
    case_type           = models.CharField(max_length=50, default='',null=True)
    new_type            = models.CharField(max_length=50, default='',null=True)
    case_nature         = models.CharField(max_length=500, default='',null=True)
    new_nature          = models.CharField(max_length=500, default='',null=True)
    reference           = models.CharField(max_length=500, default='',null=True)
    new_reference       = models.CharField(max_length=500, default='',null=True)
    refer_client        = models.CharField(max_length=500, default='',null=True)
    refer_agent         = models.CharField(max_length=500, default='',null=True)
    description         = models.CharField(max_length=1000, default='',null=True)
    recall              = models.CharField(max_length=15,default='',null=True)
    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.enquiry_name

class sale(models.Model):
    client_code         =models.CharField(max_length=15,default='',null=True)
    enquiry_code        =models.CharField(max_length=15,default='',null=True)
    enquiry_name        =models.CharField(max_length=30,default='',null=True)
    branch              =models.CharField(max_length=50, default='',null=True)
    client_type         =models.CharField(max_length=15,default='',null=True)
    date                =models.CharField(max_length=15,default='',null=True)
    location            =models.CharField(max_length=50,default='',null=True)
    district            =models.CharField(max_length=50,default='',null=True)
    mobile              =models.CharField(max_length=50,default='',null=True)
    alt_mobile          =models.CharField(max_length=50,default='',null=True)
    case_type           =models.CharField(max_length=50,default='',null=True)
    new_type            =models.CharField(max_length=50,default='',null=True)
    case_nature         =models.CharField(max_length=500,default='',null=True)
    new_nature          =models.CharField(max_length=500,default='',null=True)
    reference           =models.CharField(max_length=500,default='',null=True)
    new_reference       =models.CharField(max_length=500,default='',null=True)
    refer_client        =models.CharField(max_length=500,default='',null=True)
    refer_agent         =models.CharField(max_length=500,default='',null=True)
    description         =models.CharField(max_length=1000,default='',null=True)
    paid_status         =models.CharField(max_length=1000,default='',null=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.enquiry_name

class kyc_db(models.Model):
    client_code         =models.CharField(max_length=15,default='',null=True)
    e_code              =models.CharField(max_length=15,default='',null=True)
    client_name         =models.CharField(max_length=40,default='',null=True)
    branch              =models.CharField(max_length=50, default='',null=True)
    father_name         =models.CharField(max_length=40,default='',null=True)
    mother_name         =models.CharField(max_length=40,default='',null=True)
    gender              =models.CharField(max_length=15,default='',null=True)
    marriage            =models.CharField(max_length=15,default='',null=True)
    client_type         =models.CharField(max_length=15,default='',null=True)
    email               =models.CharField(max_length=15,default='',null=True)
    mobile              =models.CharField(max_length=50,default='',null=True)
    alt_mobile          =models.CharField(max_length=50,default='',null=True)
    paddress            =models.CharField(max_length=1000,default='',null=True)
    caddress            =models.CharField(max_length=1000,default='',null=True)
    dob                 =models.CharField(max_length=15,default='',null=True)
    photo               =models.ImageField(default='',null=True,upload_to='client_profile')
    occupation          =models.CharField(max_length=1000,default='',null=True)

    office_address      =models.CharField(max_length=1000,default='',null=True)
    off_branch              =models.CharField(max_length=20,default='',null=True)
    con_person_name     =models.CharField(max_length=40,default='',null=True)
    off_email           =models.CharField(max_length=40,default='',null=True)
    designation         =models.CharField(max_length=40,default='',null=True)
    website             =models.CharField(max_length=40,default='',null=True)
    company_type        =models.CharField(max_length=40,default='',null=True)

    case_type = models.CharField(max_length=50, default='', null=True)
    new_type = models.CharField(max_length=50, default='', null=True)
    case_nature = models.CharField(max_length=500, default='', null=True)
    new_nature = models.CharField(max_length=500, default='', null=True)
    reference           =models.CharField(max_length=500, default='',null=True)
    new_reference       =models.CharField(max_length=500, default='',null=True)
    refer_client        =models.CharField(max_length=500, default='',null=True)
    refer_agent         =models.CharField(max_length=500, default='',null=True)
    acommision          =models.CharField(max_length=20, default='',null=True)
    remark              =models.CharField(max_length=1000,default='',null=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.client_name

class closed_kyc_db(models.Model):
    client_code         =models.CharField(max_length=15,default='',null=True)
    e_code              =models.CharField(max_length=15,default='',null=True)
    client_name         =models.CharField(max_length=40,default='',null=True)
    branch = models.CharField(max_length=50, default='',null=True)
    father_name         =models.CharField(max_length=40,default='',null=True)
    mother_name         =models.CharField(max_length=40,default='',null=True)
    gender              =models.CharField(max_length=15,default='',null=True)
    marriage            =models.CharField(max_length=15,default='',null=True)
    client_type         =models.CharField(max_length=15,default='',null=True)
    email               =models.CharField(max_length=15,default='',null=True)
    mobile              =models.CharField(max_length=50,default='',null=True)
    alt_mobile          =models.CharField(max_length=50,default='',null=True)
    paddress            =models.CharField(max_length=1000,default='',null=True)
    caddress            =models.CharField(max_length=1000,default='',null=True)
    dob                 =models.CharField(max_length=15,default='',null=True)
    photo               =models.ImageField(default='',null=True,upload_to='client_profile')
    occupation          =models.CharField(max_length=1000,default='',null=True)

    office_address      =models.CharField(max_length=1000,default='',null=True)
    off_branch              =models.CharField(max_length=20,default='',null=True)
    con_person_name     =models.CharField(max_length=40,default='',null=True)
    off_email           =models.CharField(max_length=40,default='',null=True)
    designation         =models.CharField(max_length=40,default='',null=True)
    website             =models.CharField(max_length=40,default='',null=True)
    company_type        =models.CharField(max_length=40,default='',null=True)

    case_type = models.CharField(max_length=50, default='', null=True)
    new_type = models.CharField(max_length=50, default='', null=True)
    case_nature = models.CharField(max_length=500, default='', null=True)
    new_nature = models.CharField(max_length=500, default='', null=True)
    reference           =models.CharField(max_length=500, default='',null=True)
    new_reference       =models.CharField(max_length=500, default='',null=True)
    refer_client        =models.CharField(max_length=500, default='',null=True)
    refer_agent         =models.CharField(max_length=500, default='',null=True)
    acommision          =models.CharField(max_length=20, default='',null=True)
    remark              =models.CharField(max_length=1000,default='',null=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.client_name

class kyc_pending(models.Model):
    client_code         =models.CharField(max_length=15,default='',null=True)
    e_code              =models.CharField(max_length=15,default='',null=True)
    client_name         =models.CharField(max_length=40,default='',null=True)
    branch = models.CharField(max_length=50, default='',null=True)
    father_name         =models.CharField(max_length=40,default='',null=True)
    mother_name         =models.CharField(max_length=40,default='',null=True)
    gender              =models.CharField(max_length=15,default='',null=True)
    marriage            =models.CharField(max_length=15,default='',null=True)
    client_type         =models.CharField(max_length=15,default='',null=True)
    email               =models.CharField(max_length=15,default='',null=True)
    mobile              =models.CharField(max_length=50,default='',null=True)
    alt_mobile          =models.CharField(max_length=50,default='',null=True)
    paddress            =models.CharField(max_length=1000,default='',null=True)
    caddress            =models.CharField(max_length=1000,default='',null=True)
    dob                 =models.CharField(max_length=15,default='',null=True)
    photo               =models.ImageField(default='',null=True,upload_to='client_profile')
    occupation          =models.CharField(max_length=1000,default='',null=True)

    office_address      =models.CharField(max_length=1000,default='',null=True)
    off_branch              =models.CharField(max_length=20,default='',null=True)
    con_person_name     =models.CharField(max_length=40,default='',null=True)
    off_email           =models.CharField(max_length=40,default='',null=True)
    designation         =models.CharField(max_length=40,default='',null=True)
    website             =models.CharField(max_length=40,default='',null=True)
    company_type        =models.CharField(max_length=40,default='',null=True)

    case_type = models.CharField(max_length=50, default='', null=True)
    new_type = models.CharField(max_length=50, default='', null=True)
    case_nature = models.CharField(max_length=500, default='', null=True)
    new_nature = models.CharField(max_length=500, default='', null=True)
    reference           =models.CharField(max_length=500, default='',null=True)
    new_reference       =models.CharField(max_length=500, default='',null=True)
    refer_client        =models.CharField(max_length=500, default='',null=True)
    refer_agent         =models.CharField(max_length=500, default='',null=True)
    acommision          =models.CharField(max_length=20, default='',null=True)
    remark              =models.CharField(max_length=1000,default='',null=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.client_name

class agent_db(models.Model):
    agent_code          =models.CharField(max_length=15,default='',null=True)
    agent_name          =models.CharField(max_length=40,default='',null=True)
    father_name         =models.CharField(max_length=40,default='',null=True)
    mother_name         =models.CharField(max_length=40,default='',null=True)
    gender              =models.CharField(max_length=15,default='',null=True)
    marriage            =models.CharField(max_length=15,default='',null=True)
    email               =models.CharField(max_length=15,default='',null=True)
    mobile              =models.CharField(max_length=50,default='',null=True)
    alt_mobile          =models.CharField(max_length=50,default='',null=True)
    paddress            =models.CharField(max_length=1000,default='',null=True)
    caddress            =models.CharField(max_length=1000,default='',null=True)
    dob                 =models.CharField(max_length=15,default='',null=True)
    photo               =models.ImageField(default='',null=True,upload_to='agent_profile')
    occupation          =models.CharField(max_length=1000,default='',null=True)
    acommision          =models.CharField(max_length=20, default='',null=True)
    remark              =models.CharField(max_length=1000,default='',null=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.agent_name

class legal_db(models.Model):
    client_code         =models.CharField(max_length=15,default='',null=True)
    job_code            =models.CharField(max_length=15,default='',null=True)
    e_code              =models.CharField(max_length=15,default='',null=True)
    client_name         =models.CharField(max_length=40,default='',null=True)
    branch              =models.CharField(max_length=50,default='',null=True)
    father_name         =models.CharField(max_length=40,default='',null=True)
    mother_name         =models.CharField(max_length=40,default='',null=True)
    gender              =models.CharField(max_length=15,default='',null=True)
    marriage            =models.CharField(max_length=15,default='',null=True)
    client_type         =models.CharField(max_length=15,default='',null=True)
    email               =models.CharField(max_length=15,default='',null=True)
    mobile              =models.CharField(max_length=50,default='',null=True)
    alt_mobile          =models.CharField(max_length=50,default='',null=True)
    paddress            =models.CharField(max_length=1000,default='',null=True)
    caddress            =models.CharField(max_length=1000,default='',null=True)
    dob                 =models.CharField(max_length=15,default='',null=True)
    photo               =models.ImageField(default='',null=True,upload_to='client_profile')
    occupation          =models.CharField(max_length=1000,default='',null=True)

    office_address      =models.CharField(max_length=1000,default='',null=True)
    off_branch              =models.CharField(max_length=20,default='',null=True)
    con_person_name     =models.CharField(max_length=40,default='',null=True)
    off_email           =models.CharField(max_length=40,default='',null=True)
    designation         =models.CharField(max_length=40,default='',null=True)
    website             =models.CharField(max_length=40,default='',null=True)
    company_type        =models.CharField(max_length=40,default='',null=True)

    case_type = models.CharField(max_length=50, default='', null=True)
    new_type = models.CharField(max_length=50, default='', null=True)
    case_nature = models.CharField(max_length=500, default='', null=True)
    new_nature = models.CharField(max_length=500, default='', null=True)
    reference           =models.CharField(max_length=500, default='',null=True)
    new_reference       =models.CharField(max_length=500, default='',null=True)
    refer_client        =models.CharField(max_length=500, default='',null=True)
    refer_agent         =models.CharField(max_length=500, default='',null=True)
    acommision          =models.CharField(max_length=20, default='',null=True)
    remark              =models.CharField(max_length=1000,default='',null=True)
    court_location      =models.CharField(max_length=1000,default='',null=True)
    court_campus        =models.CharField(max_length=1000,default='',null=True)
    allocated           =models.CharField(max_length=1000,default='',null=True)
    panel               =models.CharField(max_length=1000,default='',null=True)
    associate           =models.CharField(max_length=1000,default='',null=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.client_name


class job_count(models.Model):
    job = models.CharField(max_length=50, default='', null=True)

    def __str__(self):
        return self.job


class legal_pending_db(models.Model):
    client_code         =models.CharField(max_length=15,default='',null=True)
    job_code            =models.CharField(max_length=15,default='',null=True)
    e_code              =models.CharField(max_length=15,default='',null=True)
    client_name         =models.CharField(max_length=40,default='',null=True)
    branch              =models.CharField(max_length=50,default='',null=True)
    father_name         =models.CharField(max_length=40,default='',null=True)
    mother_name         =models.CharField(max_length=40,default='',null=True)
    gender              =models.CharField(max_length=15,default='',null=True)
    marriage            =models.CharField(max_length=15,default='',null=True)
    client_type         =models.CharField(max_length=15,default='',null=True)
    email               =models.CharField(max_length=15,default='',null=True)
    mobile              =models.CharField(max_length=50,default='',null=True)
    alt_mobile          =models.CharField(max_length=50,default='',null=True)
    paddress            =models.CharField(max_length=1000,default='',null=True)
    caddress            =models.CharField(max_length=1000,default='',null=True)
    dob                 =models.CharField(max_length=15,default='',null=True)
    photo               =models.ImageField(default='',null=True,upload_to='client_profile')
    occupation          =models.CharField(max_length=1000,default='',null=True)

    office_address      =models.CharField(max_length=1000,default='',null=True)
    off_branch              =models.CharField(max_length=20,default='',null=True)
    con_person_name     =models.CharField(max_length=40,default='',null=True)
    off_email           =models.CharField(max_length=40,default='',null=True)
    designation         =models.CharField(max_length=40,default='',null=True)
    website             =models.CharField(max_length=40,default='',null=True)
    company_type        =models.CharField(max_length=40,default='',null=True)

    case_type = models.CharField(max_length=50, default='', null=True)
    new_type = models.CharField(max_length=50, default='', null=True)
    case_nature = models.CharField(max_length=500, default='', null=True)
    new_nature = models.CharField(max_length=500, default='', null=True)
    reference           =models.CharField(max_length=500, default='',null=True)
    new_reference       =models.CharField(max_length=500, default='',null=True)
    refer_client        =models.CharField(max_length=500, default='',null=True)
    refer_agent         =models.CharField(max_length=500, default='',null=True)
    acommision          =models.CharField(max_length=20, default='',null=True)
    remark              =models.CharField(max_length=1000,default='',null=True)
    court_location      =models.CharField(max_length=1000,default='',null=True)
    court_campus        =models.CharField(max_length=1000,default='',null=True)
    allocated           =models.CharField(max_length=1000,default='',null=True)
    panel               =models.CharField(max_length=1000, default='', null=True)
    associate           =models.CharField(max_length=1000, default='', null=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.client_name


class legal_closed_db(models.Model):
    client_code         =models.CharField(max_length=15,default='',null=True)
    job_code            =models.CharField(max_length=15,default='',null=True)
    e_code              =models.CharField(max_length=15,default='',null=True)
    client_name         =models.CharField(max_length=40,default='',null=True)
    branch              =models.CharField(max_length=50,default='',null=True)
    father_name         =models.CharField(max_length=40,default='',null=True)
    mother_name         =models.CharField(max_length=40,default='',null=True)
    gender              =models.CharField(max_length=15,default='',null=True)
    marriage            =models.CharField(max_length=15,default='',null=True)
    client_type         =models.CharField(max_length=15,default='',null=True)
    email               =models.CharField(max_length=15,default='',null=True)
    mobile              =models.CharField(max_length=50,default='',null=True)
    alt_mobile          =models.CharField(max_length=50,default='',null=True)
    paddress            =models.CharField(max_length=1000,default='',null=True)
    caddress            =models.CharField(max_length=1000,default='',null=True)
    dob                 =models.CharField(max_length=15,default='',null=True)
    photo               =models.ImageField(default='',null=True,upload_to='client_profile')
    occupation          =models.CharField(max_length=1000,default='',null=True)

    office_address      =models.CharField(max_length=1000,default='',null=True)
    off_branch          =models.CharField(max_length=20,default='',null=True)
    con_person_name     =models.CharField(max_length=40,default='',null=True)
    off_email           =models.CharField(max_length=40,default='',null=True)
    designation         =models.CharField(max_length=40,default='',null=True)
    website             =models.CharField(max_length=40,default='',null=True)
    company_type        =models.CharField(max_length=40,default='',null=True)

    case_type           =models.CharField(max_length=50, default='', null=True)
    new_type            =models.CharField(max_length=50, default='', null=True)
    case_nature         =models.CharField(max_length=500, default='', null=True)
    new_nature          =models.CharField(max_length=500, default='', null=True)
    reference           =models.CharField(max_length=500, default='',null=True)
    new_reference       =models.CharField(max_length=500, default='',null=True)
    refer_client        =models.CharField(max_length=500, default='',null=True)
    refer_agent         =models.CharField(max_length=500, default='',null=True)
    acommision          =models.CharField(max_length=20, default='',null=True)
    remark              =models.CharField(max_length=1000,default='',null=True)
    court_location      =models.CharField(max_length=1000,default='',null=True)
    court_campus        =models.CharField(max_length=1000,default='',null=True)
    allocated           =models.CharField(max_length=1000,default='',null=True)
    panel               =models.CharField(max_length=100, default='', null=True)
    associate           =models.CharField(max_length=100, default='', null=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.client_name


class court_db(models.Model):
    court_location      =models.CharField(max_length=1000, default='', null=True)
    court_campus        =models.CharField(max_length=1000, default='', null=True)


class finance_db(models.Model):
    client_code         =models.CharField(max_length=15,default='',null=True)
    job_code            =models.CharField(max_length=15,default='',null=True)
    e_code              =models.CharField(max_length=15,default='',null=True)
    client_name         =models.CharField(max_length=40,default='',null=True)
    branch              =models.CharField(max_length=50,default='',null=True)
    client_type         =models.CharField(max_length=15,default='',null=True)
    reference           =models.CharField(max_length=50,default='',null=True)
    new_reference       =models.CharField(max_length=50,default='',null=True)
    refer_client        =models.CharField(max_length=50,default='',null=True)
    refer_agent         =models.CharField(max_length=50,default='',null=True)
    acommision          =models.CharField(max_length=20,default='',null=True)
    paid_status         =models.CharField(max_length=20,default='',null=True)
    legal_notice_charge =models.CharField(max_length=20,default='',null=True)
    court_filing_charge =models.CharField(max_length=20,default='',null=True)
    inward_court_fees   =models.CharField(max_length=20,default='',null=True)
    handling_charge     =models.CharField(max_length=20,default='',null=True)
    service_charge      =models.CharField(max_length=20,default='',null=True)
    inward_othrers      =models.CharField(max_length=20,default='',null=True)
    inword_total        =models.CharField(max_length=20,default='',null=True)

    #-------------------------------------------------------------#
    outward_court_fees  =models.CharField(max_length=20,default='',null=True)
    court_official_charge=models.CharField(max_length=20,default='',null=True)
    court_summary       =models.CharField(max_length=20,default='',null=True)
    postal_charge       =models.CharField(max_length=20,default='',null=True)
    postal_stamp_record =models.CharField(max_length=20,default='',null=True)
    court_stamp_record  =models.CharField(max_length=20,default='',null=True)
    consultant          =models.CharField(max_length=20,default='',null=True)
    unofficial_charge   =models.CharField(max_length=20,default='',null=True)
    outword_total       =models.CharField(max_length=20,default='',null=True)

    #-------------------------------------------------------------#
    declared            =models.CharField(max_length=20,default='',null=True)
    received            =models.CharField(max_length=20,default='',null=True)
    pending             =models.CharField(max_length=20,default='',null=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.client_name

class notice_db(models.Model):
    client_code         =models.CharField(max_length=15,default='',null=True)
    job_code            =models.CharField(max_length=15,default='',null=True)
    e_code              =models.CharField(max_length=15,default='',null=True)
    client_name         =models.CharField(max_length=40,default='',null=True)
    branch              =models.CharField(max_length=50,default='',null=True)
    case_type           =models.CharField(max_length=50,default='',null=True)
    notice_date1        =models.CharField(max_length=50,default='',null=True)
    description1        =models.CharField(max_length=500,default='',null=True)
    notice_date2        =models.CharField(max_length=50,default='',null=True)
    description2        =models.CharField(max_length=500,default='',null=True)
    notice_date3        =models.CharField(max_length=50,default='',null=True)
    description3        =models.CharField(max_length=500,default='',null=True)
    remarks             =models.CharField(max_length=500,default='',null=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.client_name
