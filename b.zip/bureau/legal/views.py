import datetime
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from django.utils.datastructures import MultiValueDictKeyError
from django.core.exceptions import ObjectDoesNotExist
from legal.models import *

#================================================Test=========================================================
@csrf_exempt
def test(request):

    return render(request,'test.html')

#================================================404 handler=========================================================
@csrf_exempt
def page404(request,exception):
    return redirect('/')

#================================================Delete=========================================================
@csrf_exempt
def delete_db(request):
    if request.method=='POST':
        if request.POST['ok'] == 'closed':
            a=closed.objects.all()
            a.delete()
        elif(request.POST['ok'] == 'users'):
            b=users.objects.all()
            b.delete()
        elif (request.POST['ok'] == 'enquiry'):
            c = enquiry.objects.all()
            c.delete()
        elif (request.POST['ok'] == 'case_type'):
            d = case_type.objects.all()
            d.delete()
        elif (request.POST['ok'] == 'pending'):
            e= pending.objects.all()
            e.delete()
        elif (request.POST['ok'] == 'count'):
            f = count.objects.all()
            f.delete()
        elif (request.POST['ok'] == 'recall'):
            g = recall.objects.all()
            g.delete()
        elif (request.POST['ok'] == 'sale'):
            h = sale.objects.all()
            h.delete()
        elif (request.POST['ok'] == 'kyc_db'):
            i = kyc_db.objects.all()
            i.delete()
        elif (request.POST['ok'] == 'kyc_pending'):
            j = kyc_pending.objects.all()
            j.delete()
        elif (request.POST['ok'] == 'closed_kyc_db'):
            k = closed_kyc_db.objects.all()
            k.delete()
        elif (request.POST['ok'] == 'login_db'):
            l = login_db.objects.all()
            l.delete()
        elif (request.POST['ok'] == 'legal_db'):
            m = legal_db.objects.all()
            m.delete()
        elif (request.POST['ok'] == 'legal_pending_db'):
            n = legal_pending_db.objects.all()
            n.delete()
        elif (request.POST['ok'] == 'legal_closed_db'):
            o = legal_closed_db.objects.all()
            o.delete()
        elif (request.POST['ok'] == 'job_count'):
            p = job_count.objects.all()
            p.delete()
        elif (request.POST['ok'] == 'agent_db'):
            q = agent_db.objects.all()
            q.delete()
        elif (request.POST['ok'] == 'branch_db'):
            r = branch_db.objects.all()
            r.delete()
        elif (request.POST['ok'] == 'finance_db'):
            s = finance_db.objects.all()
            s.delete()
        elif (request.POST['ok'] == 'court_db'):
            t = court_db.objects.all()
            t.delete()
        elif (request.POST['ok'] == 'notice_db'):
            u = notice_db.objects.all()
            u.delete()
        return redirect('/delete')

    return render(request,'delete.html')


#================================================login=========================================================

@csrf_exempt
def index(request):
    users_db=users.objects.all()
    employee_count=len(users_db)
#=========================================Hr portal========================================================
    if request.method == 'POST':
        hr = 'hr'
        commercial='commercial'
        uname=request.POST['usr']
        password = request.POST['pwd']
        user_type = request.POST['usertype']
        if user_type =='Hr':
            user = authenticate(request, username=hr, password=password)
            if (user is not None) and user_type=='Hr' :
                login(request, user)
                messages.add_message(request, messages.INFO, 'Welcome To Human Resource Portal...!!!')
                return redirect('/dashboard')
                # return render(request, 'dashboard.html',{'count':employee_count,'x':users_db,})
            else:
                return render(request, 'index.html', {'error': 'User name or Password is Wrong'})

        elif user_type=='Commercial':
            user = authenticate(request, username=commercial, password=password)
            if (user is not None) and user_type == 'Commercial':
                login(request, user)
                messages.add_message(request, messages.INFO, 'Welcome To Commercial Portal...!!!')
                return redirect('/dashboard')
                # return render(request, 'dashboard.html',{})
            else:
                return render(request, 'index.html', {'error': 'User name or Password is Wrong'})
        elif user_type=='Legal':
            user = authenticate(request, username='legal', password=password)
            if (user is not None) and user_type == 'Legal':
                login(request, user)
                messages.add_message(request, messages.INFO, 'Welcome To Legal Portal...!!!')
                return redirect('/dashboard')
                # return render(request, 'dashboard.html',{})
            else:
                return render(request, 'index.html', {'error': 'User name or Password is Wrong'})
        elif user_type=='Finance':
            user = authenticate(request, username='finance', password=password)
            if (user is not None) and user_type == 'Finance':
                login(request, user)
                messages.add_message(request, messages.INFO, 'Welcome To Finance Portal...!!!')
                return redirect('/dashboard')
                # return render(request, 'dashboard.html',{})
            else:
                return render(request, 'index.html', {'error': 'User name or Password is Wrong'})
        elif user_type=='':
            user = authenticate(request, username='ceo', password=password)
            if (user is not None) and user_type == '':
                login(request, user)
                messages.add_message(request, messages.INFO, '             '
                                                             '                                              '
                                                             '                                  '
                                                             'சட்ட பணியக செயலி உங்களை வரவேற்கிறது ...!!!')
                return redirect('/dashboard')
                # return render(request, 'dashboard.html',{})
            else:
                return render(request, 'index.html', {'error': 'User name or Password is Wrong'})
        elif user_type=='Staff':
            if str.startswith(uname,'SLBSF'):
                user = authenticate(request, username=uname, password=password)
                if (user is not None) and user_type == 'Staff':
                    login(request, user)
                    messages.add_message(request, messages.INFO, 'Welcome To Staff Portal...!!!')
                    return redirect('/dashboard')
                    # return render(request, 'dashboard.html',{})
                else:
                    return render(request, 'index.html', {'error': 'User name or Password is Wrong'})
            else:
                return render(request, 'index.html', {'error': 'User name or Password is Wrong'})


        else:
            return render(request, 'index.html', {'error': 'User name or Password is Wrong'})

    return render(request,'index.html')
#================================================logout=========================================================

@login_required
@csrf_exempt
def signout(request):
    logout(request)
    return redirect('/')
#================================================ Hr Dashboard=========================================================
@login_required
@csrf_exempt
def dashboard(request):
    a=enquiry.objects.all()
    b=pending.objects.all()
    c=recall.objects.all()
    d=sale.objects.all()
    e=legal_db.objects.all()
    f=finance_db.objects.all()
    g=users.objects.all()

    ec=len(a)
    pc=len(b)
    rc=len(c)

    return render(request,'dashboard.html',{'ec':ec,'pc':pc,'rc':rc,'legal':e,'finance':d,'fi':f,'usr':g,'enq':a})

#================================================User Add=========================================================
@login_required
@csrf_exempt
def user_add(request):
    # Staff = len(users.objects.filter(dept__contains='Staff'))
    Staff1=users.objects.filter(staff_type__contains='Staff')
    Staff2=users.objects.filter(staff_type__contains='Panel')
    Staff3=users.objects.filter(staff_type__contains='Associate')
    sf_code1 = 'SLBSF{}0{}'.format(datetime.datetime.now().strftime('%y%m'), len(Staff1) + 1)
    sf_code2 = 'SLBPA{}0{}'.format(datetime.datetime.now().strftime('%y%m'), len(Staff2) + 1)
    sf_code3 = 'SLBAA{}0{}'.format(datetime.datetime.now().strftime('%y%m'), len(Staff3) + 1)
    if request.method=='POST':
        try:
            name = request.POST["name"]
            father_name = request.POST["fname"]
            mother_name = request.POST["mname"]
            mobile = request.POST["mobile"]
            alt_mobile = request.POST["alt_mobile"]
            email = request.POST["email"]
            mar_status = request.POST["marriage"]
            blood = request.POST["blood"]
            address = request.POST["address"]
            qualification = request.POST["qualify"]
            designation = request.POST["designation"]
            dob = request.POST["dob"]
            pincode = request.POST["pincode"]
            photo = request.FILES["photo"]
            branch= request.POST["branch"]
            staff_type= request.POST["stafftype"]
            account_level = request.POST["level"]
            uid= request.POST["uid"]
            password= request.POST["pwd"]

            x=users(name=name,father_name=father_name,mother_name=mother_name,mobile=mobile,alt_mobile=alt_mobile,
                email=email,mar_status=mar_status,blood=blood,address=address,qualification=qualification,designation=designation,
                dob=dob,pincode=pincode,photo=photo,account_level=account_level,branch=branch, staff_type=staff_type,uid=uid,password=password)
            x.save()

            if staff_type == 'Staff' :
                user_date=login_db(account_level=account_level,uid=uid,password=password,name=name,branch=branch)
                log = User.objects.create_user(username=uid, password=password,first_name=name,last_name=father_name,email=email, is_staff='True')
                log.save()
                user_date.save()
            messages.add_message(request, messages.INFO, 'Employee Is Created...!!!')
            return redirect('/user_list')
        except MultiValueDictKeyError:
            return redirect('/user_add')

    bnch=branch_db.objects.all()

    return render(request,'user_add.html',{'branch':bnch,'sf':sf_code1,'pa':sf_code2,'aa':sf_code3})


#================================================User list=========================================================
@login_required
@csrf_exempt
def user_list(request):
    x=users.objects.all()
    return render(request,'user_list.html',{'x':x})


#================================================panel list=========================================================
@login_required
@csrf_exempt
def panel_list(request):
    x=users.objects.filter(staff_type__contains='Panel')

    return render(request,'panel_list.html',{'x':x})
#================================================associate list=========================================================
@login_required
@csrf_exempt
def associate_list(request):
    x=users.objects.filter(staff_type__contains='Associate')
    return render(request,'associate_list.html',{'x':x})
#================================================User Edit=========================================================
@login_required
@csrf_exempt
def user_edit(request,id):
    x=users.objects.get(id=id)
    return render(request,'user_edit.html',{'x':x})

#================================================User Update=========================================================
@login_required
@csrf_exempt
def user_update(request,id):
    if request.method=='POST':
        x=users.objects.get(id=id)
        x.name = request.POST["name"]
        x.father_name = request.POST["fname"]
        x.mother_name = request.POST["mname"]
        x.mobile = request.POST["mobile"]
        x.alt_mobile = request.POST["mobile"]
        x.email = request.POST["email"]
        x.mar_status = request.POST["marriage"]
        x.blood = request.POST["blood"]
        x.address = request.POST["address"]
        x.qualification = request.POST["qualify"]
        x.designation = request.POST["designation"]
        x.dob = request.POST["dob"]
        x.pincode = request.POST["pincode"]
        x.account_level = request.POST["level"]
        x.status=request.POST["act"]
        try:
            x.photo = request.FILES["photo"]
            x.save()
        except MultiValueDictKeyError:
            x.save()

        if x.status == 'Active':
            log=    User.objects.filter(username__exact=x.uid).get()
            log.is_active=True
            log.save()
        elif x.status == 'Deactive':
            log=    User.objects.filter(username__exact=x.uid).get()
            log.is_active=False
            log.save()

        messages.add_message(request, messages.INFO, 'Data is Updated...!!!')
        return redirect('/user_list')

    return render(request,'user_edit.html')


#================================================User_Delete=========================================================

@login_required()
@csrf_exempt
def user_delete(request,id):
    x=users.objects.get(id=id)
    x.delete()
    staff=x.staff_type
    if staff=='Staff':
        y=User.objects.get(username=x.uid)
        y.delete()
    messages.add_message(request, messages.INFO, 'Data Deleted...!!!')
    return redirect('/user_list')

#================================================Enquiry Add=========================================================
@login_required()
@csrf_exempt
def enquiry_add(request):
    enquiry_db = count.objects.all()

    date = datetime.datetime.now().strftime('%d-%m-%Y %H:%M:%S')
    ecode='SLBEC{}0{}'.format(datetime.datetime.now().strftime('%y%m'),(len(enquiry_db)+1))

    if request.method=='POST':
        enquiry_code=request.POST["ecode"]
        enquiry_name=request.POST["ename"]
        branch=request.POST["mbranch"]
        clnt_type=request.POST["clienttype"]
        date=request.POST["date"]
        location=request.POST["location"]
        district=request.POST["dist"]
        mobile=request.POST["mob"]
        alt_mobile=request.POST["altmob"]
        case_types=request.POST["casetype"]
        new_type=request.POST["ncase"]
        case_natures=request.POST["casenature"]
        new_nature=request.POST["nnature"]
        refer=request.POST["refer"]
        new_refer=request.POST["nrefer"]
        referclient=request.POST["rclient"]
        referagent=request.POST["ragent"]
        description=request.POST["desc"]
        recall_date=request.POST["recalldate"]

        case_type_save=case_type(new_case_type=new_type,new_case_nature=new_nature,new_reference=new_refer)
        j=new_type,new_nature,new_refer
        for i in j:
            if i!='Null' :
                case_type_save.save()
        enquiry_save = enquiry(enquiry_code=enquiry_code,branch=branch, enquiry_name=enquiry_name, date=date, location=location,
                               district=district,
                               mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,
                               case_nature=case_natures,
                               new_nature=new_nature, reference=refer, new_reference=new_refer, description=description,
                               client_type=clnt_type, refer_client=referclient, refer_agent=referagent)
        enquiry_save.save()

        if request.POST["save"]=='save':

            count_db = count.objects.create(name=enquiry_name)
            messages.add_message(request, messages.INFO, 'Enquiry is Added...!!!')
            return redirect('/enquiry_list')
        elif request.POST["save"]=='pending':
            pending_save = pending(enquiry_code=enquiry_code,branch=branch, enquiry_name=enquiry_name, date=date, location=location,district=district,
                                   mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,case_nature=case_natures,
                                   new_nature=new_nature, reference=refer,new_reference=new_refer,description=description,
                                   client_type=clnt_type,refer_client=referclient,refer_agent=referagent)
            count_db = count.objects.create(name=enquiry_name)

            pending_save.save()
            messages.add_message(request, messages.INFO, 'Added Pending...!!!')
            return redirect('/pending_list')
        elif request.POST["save"]=='recall':
            recall_save = recall(enquiry_code=enquiry_code,branch=branch, enquiry_name=enquiry_name, date=date, location=location,district=district,
                                   mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,case_nature=case_natures,
                                   new_nature=new_nature, reference=refer,new_reference=new_refer,description=description,
                                   client_type=clnt_type,refer_client=referclient,refer_agent=referagent,recall=recall_date)
            count_db = count.objects.create(name=enquiry_name)

            recall_save.save()
            messages.add_message(request, messages.INFO, 'Added Recall...!!!')
            return redirect('/recall_today')
        elif request.POST['save'] == 'close':
            closed_save = closed(enquiry_code=enquiry_code,branch=branch, enquiry_name=enquiry_name, date=date, location=location,district=district,
                                   mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,case_nature=case_natures,
                                   new_nature=new_nature, reference=refer,new_reference=new_refer,description=description,
                                   client_type=clnt_type,refer_client=referclient,refer_agent=referagent)

            count_db = count.objects.create(name=enquiry_name)

            closed_save.save()
            messages.add_message(request, messages.INFO, 'Data is Closed...!!!')
            return redirect('/enquiry_list')
        elif request.POST['save'] == 'sale':
            sale_count=sale.objects.all()
            client_code = 'SLBCL{}0{}'.format(datetime.datetime.now().strftime('%y%m'), (len(sale_count) + 1))

            sale_save = sale(client_code=client_code, enquiry_code=enquiry_code,branch=branch, enquiry_name=enquiry_name, date=date, location=location,district=district,
                                   mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,case_nature=case_natures,
                                   new_nature=new_nature, reference=refer,new_reference=new_refer,description=description,
                                   client_type=clnt_type,refer_client=referclient,refer_agent=referagent)

            count_db = count.objects.create(name=enquiry_name)

            sale_save.save()

            try:

                ag_code = referagent
                ag_fee = agent_db.objects.filter(agent_code__exact=ag_code).get()
                ag_commision = ag_fee.acommision

                finance_save = finance_db(client_code=client_code, acommision=ag_commision, e_code=enquiry_code,
                                          client_name=enquiry_name,
                                          branch=branch, client_type=clnt_type, reference=refer,
                                          new_reference=new_refer, refer_client=referclient,
                                          refer_agent=referagent)
                finance_save.save()
            except ObjectDoesNotExist:
                finance_save = finance_db(client_code=client_code, e_code=enquiry_code,
                                          client_name=enquiry_name,
                                          branch=branch, client_type=clnt_type, reference=refer,
                                          new_reference=new_refer, refer_client=referclient,
                                          refer_agent=referagent)
                finance_save.save()
            messages.add_message(request, messages.INFO, 'Data is Move to Sales...!!!')
            return redirect('/sales_view')


    case=case_type.objects.all()
    clnt=sale.objects.all()
    agnt=agent_db.objects.all()
    branch_d=branch_db.objects.all()
    return render(request,'enquiry_add.html',{'xx':case,'ecode':ecode,'clnt':clnt,'agnt':agnt,'branch':branch_d})

#================================================Enquiry View=========================================================
@login_required()
@csrf_exempt
def enquiry_list(request):
    x=enquiry.objects.all()
    return render(request,'enquiry_list.html',{'x':x})
#================================================Enquiry Edit=========================================================
@login_required()
@csrf_exempt
def enquiry_edit(request,id):
    x=enquiry.objects.get(id=id)
    case=case_type.objects.all()
    clnt = sale.objects.all()
    agnt = agent_db.objects.all()
    branch_d=branch_db.objects.all()
    return render(request,'enquiry_edit.html',{'x':x,'xx':case,'clnt':clnt,'agnt':agnt,'branch':branch_d})


#================================================Enquiry Edit=========================================================
@login_required()
@csrf_exempt
def enquiry_update(request,id):
    x=enquiry.objects.get(id=id)
    if request.method=='POST':
        x.enquiry_code = request.POST["ecode"]
        x.enquiry_name = request.POST["ename"]
        x.branch= request.POST["mbranch"]
        x.client_type = request.POST["clienttype"]
        x.date = request.POST["date"]
        x.location = request.POST["location"]
        x.district = request.POST["dist"]
        x.mobile = request.POST["mob"]
        x.alt_mobile = request.POST["altmob"]
        if request.POST['casetype']=='othertype':
            x.case_type = request.POST["casetype"]
            x.new_type = request.POST["ncase"]
        else:
            x.case_type = request.POST["casetype"]
            x.new_type = 'Null'
        if request.POST['casenature']=='othernature':
            x.case_nature = request.POST["casenature"]
            x.new_nature = request.POST["nnature"]
        else:
            x.case_nature = request.POST["casenature"]
            x.new_nature = "Null"

        if request.POST["refer"] == 'Direct' or 'Telecall':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
        if request.POST['refer'] == 'Via_Client':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = request.POST["rclient"]
            x.refer_agent = 'Null'
        if request.POST['refer'] == 'Via_Agent':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = request.POST["ragent"]
        if request.POST['refer'] == 'otherrefer':
            x.reference = request.POST["refer"]
            x.new_reference = request.POST['nrefer']
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
        # else:
        #     pass
        x.description = request.POST["desc"]

        #===============================================================================
        enquiry_code = request.POST["ecode"]
        enquiry_name = request.POST["ename"]
        branch = request.POST["mbranch"]
        clnt_type = request.POST["clienttype"]
        date = request.POST["date"]
        location = request.POST["location"]
        district = request.POST["dist"]
        mobile = request.POST["mob"]
        alt_mobile = request.POST["altmob"]
        case_types = request.POST["casetype"]
        new_type = request.POST["ncase"]
        case_natures = request.POST["casenature"]
        new_nature = request.POST["nnature"]
        refer = request.POST["refer"]
        new_refer = request.POST["nrefer"]
        referclient = request.POST["rclient"]
        referagent = request.POST["ragent"]
        description = request.POST["desc"]
        #===============================================================================

        if request.POST["save"] == 'update':
            x.save()
            messages.add_message(request, messages.INFO, 'Data Updated...!!!')
            return redirect('/enquiry_list')
        elif request.POST['save'] == 'close':
            closed_save = closed(enquiry_code=enquiry_code,branch=branch, enquiry_name=enquiry_name, date=date, location=location,district=district,
                                   mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,case_nature=case_natures,
                                   new_nature=new_nature, reference=refer,new_reference=new_refer,description=description,
                                   client_type=clnt_type,refer_client=referclient,refer_agent=referagent)

            closed_save.save()
            x.delete()
            messages.add_message(request, messages.INFO, 'Data is Closed...!!!')
            return redirect('/enquiry_list')

        elif request.POST["save"] == 'pending':
            enquiry_code = request.POST["ecode"]
            enquiry_name = request.POST["ename"]
            branch= request.POST["mbranch"]
            clnt_type = request.POST["clienttype"]
            date = request.POST["date"]
            location = request.POST["location"]
            district = request.POST["dist"]
            mobile = request.POST["mob"]
            alt_mobile = request.POST["altmob"]
            case_types = request.POST["casetype"]
            new_type = request.POST["ncase"]
            case_natures = request.POST["casenature"]
            new_nature = request.POST["nnature"]
            refer = request.POST["refer"]
            new_refer = request.POST["nrefer"]
            referclient = request.POST["rclient"]
            referagent = request.POST["ragent"]
            description = request.POST["desc"]

            pending_save= pending(enquiry_code=enquiry_code, enquiry_name=enquiry_name,branch=branch, date=date, location=location,district=district,
                                   mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,case_nature=case_natures,
                                   new_nature=new_nature, reference=refer,new_reference=new_refer,description=description,
                                   client_type=clnt_type,refer_client=referclient,refer_agent=referagent)
            pending_save.save()
            # x.delete()
            messages.add_message(request, messages.INFO, 'Data Move to Pending...!!!')
            return redirect('/pending_list')


        elif request.POST["save"] == 'recall':
            enquiry_code = request.POST["ecode"]
            enquiry_name = request.POST["ename"]
            branch= request.POST["mbranch"]
            clnt_type = request.POST["clienttype"]
            date = request.POST["date"]
            location = request.POST["location"]
            district = request.POST["dist"]
            mobile = request.POST["mob"]
            alt_mobile = request.POST["altmob"]
            case_types = request.POST["casetype"]
            new_type = request.POST["ncase"]
            case_natures = request.POST["casenature"]
            new_nature = request.POST["nnature"]
            refer = request.POST["refer"]
            new_refer = request.POST["nrefer"]
            referclient = request.POST["rclient"]
            referagent = request.POST["ragent"]
            description = request.POST["desc"]
            recall_date = request.POST["recalldate"]

            recall_save = recall(enquiry_code=enquiry_code, enquiry_name=enquiry_name,branch=branch, date=date, location=location,district=district,
                                   mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,case_nature=case_natures,
                                   new_nature=new_nature, reference=refer,new_reference=new_refer,description=description,
                                   client_type=clnt_type,refer_client=referclient,refer_agent=referagent,recall=recall_date)
            recall_save.save()
            # x.delete()
            messages.add_message(request, messages.INFO, 'Data Move to Recall...!!!')
            return redirect('/recall_list')
        elif request.POST["save"] == 'sale':
            enquiry_code = request.POST["ecode"]
            enquiry_name = request.POST["ename"]
            branch= request.POST["mbranch"]
            clnt_type = request.POST["clienttype"]
            date = request.POST["date"]
            location = request.POST["location"]
            district = request.POST["dist"]
            mobile = request.POST["mob"]
            alt_mobile = request.POST["altmob"]
            case_types = request.POST["casetype"]
            new_type = request.POST["ncase"]
            case_natures = request.POST["casenature"]
            new_nature = request.POST["nnature"]
            refer = request.POST["refer"]
            new_refer = request.POST["nrefer"]
            referclient = request.POST["rclient"]
            referagent = request.POST["ragent"]
            description = request.POST["desc"]

            sale_count = sale.objects.all()
            client_code = 'SLBCL{}0{}'.format(datetime.datetime.now().strftime('%y%m'), (len(sale_count) + 1))

            sale_save= sale( client_code=client_code,enquiry_code=enquiry_code, enquiry_name=enquiry_name,branch=branch, date=date, location=location,district=district,
                                   mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,case_nature=case_natures,
                                   new_nature=new_nature, reference=refer,new_reference=new_refer,description=description,
                                   client_type=clnt_type,refer_client=referclient,refer_agent=referagent)
            sale_save.save()
            # x.delete()
            try:

                ag_code = referagent
                ag_fee = agent_db.objects.filter(agent_code__exact=ag_code).get()
                ag_commision = ag_fee.acommision

                finance_save=finance_db(client_code=client_code, acommision = ag_commision,e_code=enquiry_code,client_name=enquiry_name,
                                        branch=branch,client_type=clnt_type,reference=refer,new_reference=new_refer,refer_client=referclient,
                                        refer_agent=referagent)
                finance_save.save()
            except ObjectDoesNotExist:
                finance_save = finance_db(client_code=client_code, e_code=enquiry_code,
                                          client_name=enquiry_name,
                                          branch=branch, client_type=clnt_type, reference=refer,
                                          new_reference=new_refer, refer_client=referclient,
                                          refer_agent=referagent)
                finance_save.save()
            messages.add_message(request, messages.INFO, 'Data is Move to Sale...!!!')
            return redirect('/sales_view')
        else:
            pass

    return redirect('/enquiry_list')
#================================================Enquiry Pending View=========================================================
@login_required()
@csrf_exempt
def pending_list(request):
    x=pending.objects.all()
    clnt = sale.objects.all()
    agnt = agent_db.objects.all()
    return render(request,'pending_list.html',{'x':x, 'clnt': clnt, 'agnt': agnt})

#================================================Enquiry Recall View=========================================================
@login_required()
@csrf_exempt
def recall_list(request):
    x=recall.objects.all()
    return render(request,'recall_list.html',{'x':x})

#================================================Pending Edit=================================================================
@login_required()
@csrf_exempt
def pending_edit(request,id):
    x=pending.objects.get(id=id)
    clnt = sale.objects.all()
    agnt = agent_db.objects.all()
    branch_d=branch_db.objects.all()
    case = case_type.objects.all()
    return render(request,'pending_edit.html',{'x':x,'xx':case ,'clnt': clnt, 'agnt': agnt,'branch':branch_d})

#================================================Pending Update=================================================================

@login_required()
@csrf_exempt
def pending_update(request,id):
    x=pending.objects.get(id=id)
    if request.method=='POST':
        x.enquiry_code = request.POST["ecode"]
        x.enquiry_name = request.POST["ename"]
        x.branch= request.POST["mbranch"]
        x.client_type = request.POST["clienttype"]
        x.date = request.POST["date"]
        x.location = request.POST["location"]
        x.district = request.POST["dist"]
        x.mobile = request.POST["mob"]
        x.alt_mobile = request.POST["altmob"]
        if request.POST['casetype'] == 'othertype':
            x.case_type = request.POST["casetype"]
            x.new_type = request.POST["ncase"]
        else:
            x.case_type = request.POST["casetype"]
            x.new_type = 'Null'
        if request.POST['casenature'] == 'othernature':
            x.case_nature = request.POST["casenature"]
            x.new_nature = request.POST["nnature"]
        else:
            x.case_nature = request.POST["casenature"]
            x.new_nature = "Null"

        if request.POST["refer"] == 'Direct' or 'Telecall':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
        if request.POST['refer'] == 'Via_Client':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = request.POST["rclient"]
            x.refer_agent = 'Null'
        if request.POST['refer'] == 'Via_Agent':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = request.POST["ragent"]
        if request.POST['refer'] == 'otherrefer':
            x.reference = request.POST["refer"]
            x.new_reference = request.POST['nrefer']
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
        x.description = request.POST["desc"]

        if request.POST["save"] == 'update':
            x.save()
            messages.add_message(request, messages.INFO, 'Data Updated...!!!')
            return redirect('/pending_list')

        elif request.POST["save"] == 'recall':
            enquiry_code = request.POST["ecode"]
            enquiry_name = request.POST["ename"]
            branch= request.POST["mbranch"]
            clnt_type = request.POST["clienttype"]
            date = request.POST["date"]
            location = request.POST["location"]
            district = request.POST["dist"]
            mobile = request.POST["mob"]
            alt_mobile = request.POST["altmob"]
            case_types = request.POST["casetype"]
            new_type = request.POST["ncase"]
            case_natures = request.POST["casenature"]
            new_nature = request.POST["nnature"]
            refer = request.POST["refer"]
            new_refer = request.POST["nrefer"]
            referclient = request.POST["rclient"]
            referagent = request.POST["ragent"]
            description = request.POST["desc"]
            recall_date = request.POST["recalldate"]

            recall_save = recall(enquiry_code=enquiry_code,branch=branch, enquiry_name=enquiry_name, date=date, location=location,district=district,
                                   mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,case_nature=case_natures,
                                   new_nature=new_nature, reference=refer,new_reference=new_refer,description=description,
                                   client_type=clnt_type,refer_client=referclient,refer_agent=referagent,recall=recall_date)
            recall_save.save()
            x.delete()
            messages.add_message(request, messages.INFO, 'Data Move to recall...!!!')
            return redirect('/recall_list')

        elif request.POST["save"] == 'pending':
            enquiry_code = request.POST["ecode"]
            enquiry_name = request.POST["ename"]
            branch= request.POST["mbranch"]
            clnt_type = request.POST["clienttype"]
            date = request.POST["date"]
            location = request.POST["location"]
            district = request.POST["dist"]
            mobile = request.POST["mob"]
            alt_mobile = request.POST["altmob"]
            case_types = request.POST["casetype"]
            new_type = request.POST["ncase"]
            case_natures = request.POST["casenature"]
            new_nature = request.POST["nnature"]
            refer = request.POST["refer"]
            new_refer = request.POST["nrefer"]
            referclient = request.POST["rclient"]
            referagent = request.POST["ragent"]
            description = request.POST["desc"]

            pending_save= pending(enquiry_code=enquiry_code,branch=branch, enquiry_name=enquiry_name, date=date, location=location,district=district,
                                   mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,case_nature=case_natures,
                                   new_nature=new_nature, reference=refer,new_reference=new_refer,description=description,
                                   client_type=clnt_type,refer_client=referclient,refer_agent=referagent)
            pending_save.save()
            x.delete()
            messages.add_message(request, messages.INFO, 'Data Move to Pending...!!!')
            return redirect('/pending_list')

        elif request.POST["save"] == 'sale':
            enquiry_code = request.POST["ecode"]
            enquiry_name = request.POST["ename"]
            branch= request.POST["mbranch"]
            clnt_type = request.POST["clienttype"]
            date = request.POST["date"]
            location = request.POST["location"]
            district = request.POST["dist"]
            mobile = request.POST["mob"]
            alt_mobile = request.POST["altmob"]
            case_types = request.POST["casetype"]
            new_type = request.POST["ncase"]
            case_natures = request.POST["casenature"]
            new_nature = request.POST["nnature"]
            refer = request.POST["refer"]
            new_refer = request.POST["nrefer"]
            referclient = request.POST["rclient"]
            referagent = request.POST["ragent"]
            description = request.POST["desc"]

            sale_count = sale.objects.all()
            client_code = 'SLBCL{}0{}'.format(datetime.datetime.now().strftime('%y%m'), (len(sale_count) + 1))
            sale_save= sale(client_code=client_code,enquiry_code=enquiry_code,branch=branch, enquiry_name=enquiry_name, date=date, location=location,district=district,
                                   mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,case_nature=case_natures,
                                   new_nature=new_nature, reference=refer,new_reference=new_refer,description=description,
                                   client_type=clnt_type,refer_client=referclient,refer_agent=referagent)
            sale_save.save()
            x.delete()

            try:

                ag_code = referagent
                ag_fee = agent_db.objects.filter(agent_code__exact=ag_code).get()
                ag_commision = ag_fee.acommision

                finance_save = finance_db(client_code=client_code, acommision=ag_commision, e_code=enquiry_code,
                                          client_name=enquiry_name,
                                          branch=branch, client_type=clnt_type, reference=refer,
                                          new_reference=new_refer, refer_client=referclient,
                                          refer_agent=referagent)
                finance_save.save()
            except ObjectDoesNotExist:
                finance_save = finance_db(client_code=client_code, e_code=enquiry_code,
                                          client_name=enquiry_name,
                                          branch=branch, client_type=clnt_type, reference=refer,
                                          new_reference=new_refer, refer_client=referclient,
                                          refer_agent=referagent)
                finance_save.save()
            messages.add_message(request, messages.INFO, 'Data is Move to Sale...!!!')
            return redirect('/sales_view')

    return redirect('/pending_list')

#================================================Recall Edit=================================================================
@login_required()
@csrf_exempt
def recall_edit(request,id):
    x=recall.objects.get(id=id)
    clnt = sale.objects.all()
    agnt = agent_db.objects.all()
    branch_d=branch_db.objects.all()
    case = case_type.objects.all()
    return render(request,'recall_edit.html',{'x':x,'clnt': clnt,'xx':case, 'agnt': agnt,'branch':branch_d})

#================================================Recall Update=================================================================

@login_required()
@csrf_exempt
def recall_update(request,id):
    x=recall.objects.get(id=id)
    if request.method=='POST':
        x.enquiry_code = request.POST["ecode"]
        x.enquiry_name = request.POST["ename"]
        x.branch= request.POST["mbranch"]
        x.client_type = request.POST["clienttype"]
        x.date = request.POST["date"]
        x.location = request.POST["location"]
        x.district = request.POST["dist"]
        x.mobile = request.POST["mob"]
        x.alt_mobile = request.POST["altmob"]
        if request.POST['casetype'] == 'othertype':
            x.case_type = request.POST["casetype"]
            x.new_type = request.POST["ncase"]
        else:
            x.case_type = request.POST["casetype"]
            x.new_type = 'Null'
        if request.POST['casenature'] == 'othernature':
            x.case_nature = request.POST["casenature"]
            x.new_nature = request.POST["nnature"]
        else:
            x.case_nature = request.POST["casenature"]
            x.new_nature = "Null"

        if request.POST["refer"] == 'Direct' or 'Telecall':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
        if request.POST['refer'] == 'Via_Client':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = request.POST["rclient"]
            x.refer_agent = 'Null'
        if request.POST['refer'] == 'Via_Agent':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = request.POST["ragent"]
        if request.POST['refer'] == 'otherrefer':
            x.reference = request.POST["refer"]
            x.new_reference = request.POST['nrefer']
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
        x.description = request.POST["desc"]
        x.recall = request.POST["recalldate"]

        if request.POST["save"] == 'update':
            x.save()
            messages.add_message(request, messages.INFO, 'Data Updated...!!!')
            return redirect('/recall_today_list')

        elif request.POST["save"] == 'pending':
            enquiry_code = request.POST["ecode"]
            enquiry_name = request.POST["ename"]
            branch= request.POST["mbranch"]
            clnt_type = request.POST["clienttype"]
            date = request.POST["date"]
            location = request.POST["location"]
            district = request.POST["dist"]
            mobile = request.POST["mob"]
            alt_mobile = request.POST["altmob"]
            case_types = request.POST["casetype"]
            new_type = request.POST["ncase"]
            case_natures = request.POST["casenature"]
            new_nature = request.POST["nnature"]
            refer = request.POST["refer"]
            new_refer = request.POST["nrefer"]
            referclient = request.POST["rclient"]
            referagent = request.POST["ragent"]
            description = request.POST["desc"]

            pending_save= pending(enquiry_code=enquiry_code, enquiry_name=enquiry_name,branch=branch, date=date, location=location,
                                   district=district,mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,
                                   case_nature=case_natures,new_nature=new_nature, reference=refer, new_reference=new_refer,
                                   description=description,client_type=clnt_type, refer_client=referclient, refer_agent=referagent)
            pending_save.save()
            x.delete()
            messages.add_message(request, messages.INFO, 'Data is Move to Pending...!!!')
            return redirect('/pending_list')

        elif request.POST["save"] == 'sale':
            enquiry_code = request.POST["ecode"]
            enquiry_name = request.POST["ename"]
            branch= request.POST["mbranch"]
            clnt_type = request.POST["clienttype"]
            date = request.POST["date"]
            location = request.POST["location"]
            district = request.POST["dist"]
            mobile = request.POST["mob"]
            alt_mobile = request.POST["altmob"]
            case_types = request.POST["casetype"]
            new_type = request.POST["ncase"]
            case_natures = request.POST["casenature"]
            new_nature = request.POST["nnature"]
            refer = request.POST["refer"]
            new_refer = request.POST["nrefer"]
            referclient = request.POST["rclient"]
            referagent = request.POST["ragent"]
            description = request.POST["desc"]

            sale_count = sale.objects.all()
            client_code = 'SLBCL{}0{}'.format(datetime.datetime.now().strftime('%y%m'), (len(sale_count) + 1))

            sale_save= sale(client_code=client_code,enquiry_code=enquiry_code, enquiry_name=enquiry_name,branch=branch, date=date, location=location,
                                   district=district,mobile=mobile, alt_mobile=alt_mobile, case_type=case_types, new_type=new_type,
                                   case_nature=case_natures,new_nature=new_nature, reference=refer, new_reference=new_refer,
                                   description=description,client_type=clnt_type, refer_client=referclient, refer_agent=referagent)
            sale_save.save()
            x.delete()

            try:

                ag_code = referagent
                ag_fee = agent_db.objects.filter(agent_code__exact=ag_code).get()
                ag_commision = ag_fee.acommision

                finance_save = finance_db(client_code=client_code, acommision=ag_commision, e_code=enquiry_code,
                                          client_name=enquiry_name,
                                          branch=branch, client_type=clnt_type, reference=refer,
                                          new_reference=new_refer, refer_client=referclient,
                                          refer_agent=referagent)
                finance_save.save()
            except ObjectDoesNotExist:
                finance_save = finance_db(client_code=client_code, e_code=enquiry_code,
                                          client_name=enquiry_name,
                                          branch=branch, client_type=clnt_type, reference=refer,
                                          new_reference=new_refer, refer_client=referclient,
                                          refer_agent=referagent)
                finance_save.save()
            messages.add_message(request, messages.INFO, 'Data is Move to Sale...!!!')
            return redirect('/sales_view')

    return redirect('/recall_list')

#================================================Recall List Today=================================================================
@login_required()
@csrf_exempt
def recall_list_today(request):
    date = datetime.datetime.now().strftime('%d/%m/%Y')
    x = recall.objects.filter(recall__contains=date)
    return render(request,'recall_list_today.html',{'x':x})

#================================================Sale detailes=================================================================
@login_required()
@csrf_exempt
def sale_list(request):
    x=sale.objects.all()
    return render(request,'sales_total_view.html',{'x':x})

#================================================Sale detailes=================================================================
@login_required()
@csrf_exempt
def sale_edit(request,id):
    x=sale.objects.get(id=id)
    clnt = sale.objects.all()
    agnt = agent_db.objects.all()
    branch_d=branch_db.objects.all()
    case = case_type.objects.all()
    return render(request,'sales_edit.html',{'x':x,'xx':case, 'clnt': clnt, 'agnt': agnt,'branch':branch_d})

#================================================Recall Update=================================================================

@login_required()
@csrf_exempt
def sales_update(request,id):
    x=sale.objects.get(id=id)
    if request.method=='POST':
        # x.enquiry_code = request.POST["ecode"]
        x.enquiry_name = request.POST["ename"]
        x.branch= request.POST["mbranch"]
        x.client_type = request.POST["clienttype"]
        x.date = request.POST["date"]
        x.location = request.POST["location"]
        x.district = request.POST["dist"]
        x.mobile = request.POST["mob"]
        x.alt_mobile = request.POST["altmob"]
        if request.POST['casetype'] == 'othertype':
            x.case_type = request.POST["casetype"]
            x.new_type = request.POST["ncase"]
        else:
            x.case_type = request.POST["casetype"]
            x.new_type = 'Null'
        if request.POST['casenature'] == 'othernature':
            x.case_nature = request.POST["casenature"]
            x.new_nature = request.POST["nnature"]
        else:
            x.case_nature = request.POST["casenature"]
            x.new_nature = "Null"

        if request.POST["refer"] == 'Direct' or 'Telecall':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
        if request.POST['refer'] == 'Via_Client':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = request.POST["rclient"]
            x.refer_agent = 'Null'
        if request.POST['refer'] == 'Via_Agent':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = request.POST["ragent"]
        if request.POST['refer'] == 'otherrefer':
            x.reference = request.POST["refer"]
            x.new_reference = request.POST['nrefer']
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
        x.description = request.POST["desc"]

        if request.POST["save"] == 'close':
            x.save()
            messages.add_message(request, messages.INFO, 'Data Updated...!!!')
            return redirect('/sales_view')

    return redirect('/sales_view')


#================================================Kyc add=================================================================
@login_required()
@csrf_exempt
def kyc_add(request,id):
    x=sale.objects.get(id=id)
    if request.method=='POST':
        ecode = request.POST["ecode"]
        client_name = request.POST["cname"]
        branch = request.POST["mbranch"]
        father_name = request.POST["fname"]
        mother_name = request.POST["mname"]
        gender = request.POST["gender"]
        marriage = request.POST["marriage"]
        clienttype = request.POST["clienttype"]
        email = request.POST["email"]
        mob = request.POST["mob"]
        altmob = request.POST["altmob"]
        paddress = request.POST["padd"]
        caddress = request.POST["cadd"]
        dob = request.POST["dob"]
        photo = request.FILES["photo"]
        occupation = request.POST["occ"]
        off_add = request.POST["offadd"]
        off_branch = request.POST["branch"]
        cpname = request.POST["cpname"]
        offemail = request.POST["offemail"]
        design = request.POST["des"]
        website = request.POST["web"]
        com_type = request.POST["comtype"]
        case_types = request.POST["casetype"]
        new_type = request.POST["ncase"]
        case_natures = request.POST["casenature"]
        new_nature = request.POST["nnature"]
        refer = request.POST["refer"]
        new_refer = request.POST["nrefer"]
        referclient = request.POST["rclient"]
        referagent = request.POST["ragent"]
        agent_com = request.POST["acom"]
        remark = request.POST["remark"]
        client_code=x.client_code
        kyc_save= kyc_db(e_code=ecode, client_code=client_code,client_name=client_name, father_name=father_name,
                                  mother_name=mother_name, gender=gender,
                                  marriage=marriage,
                                  client_type=clienttype, email=email, mobile=mob, alt_mobile=altmob,branch=branch, paddress=paddress,
                                  caddress=caddress,
                                  dob=dob, photo=photo, occupation=occupation, office_address=off_add, off_branch=off_branch,
                                  con_person_name=cpname,
                                  off_email=offemail, designation=design, website=website, company_type=com_type,
                                  reference=refer,case_type=case_types, new_type=new_type,
                                   case_nature=case_natures,new_nature=new_nature,
                                  new_reference=new_refer, refer_client=referclient, refer_agent=referagent,
                                  acommision=agent_com, remark=remark)
        kyc_save.save()

        if request.POST["save"] == 'close':
            kyc_close= closed_kyc_db(client_code=client_code,e_code=ecode,client_name=client_name, off_branch=off_branch,father_name=father_name, mother_name=mother_name, gender=gender,
                            marriage=marriage,
                            client_type=clienttype, email=email, mobile=mob, alt_mobile=altmob, paddress=paddress,
                            caddress=caddress,
                            dob=dob, photo=photo, occupation=occupation, office_address=off_add, branch=branch,
                            con_person_name=cpname,
                            off_email=offemail, designation=design, website=website, company_type=com_type,
                            case_type=case_types, new_type=new_type,case_nature=case_natures, new_nature=new_nature,
                            reference=refer,new_reference=new_refer, refer_client=referclient, refer_agent=referagent,
                            acommision=agent_com, remark=remark)
            kyc_close.save()
            messages.add_message(request, messages.INFO, 'Data is Closed...!!!')
            return redirect('/sales_view')

        elif request.POST["save"] == 'pending':
            kyc_pending_save = kyc_pending(client_code=client_code,e_code=ecode, client_name=client_name,off_branch=off_branch, father_name=father_name,
                                      mother_name=mother_name, gender=gender,
                                      marriage=marriage,
                                      client_type=clienttype, email=email, mobile=mob, alt_mobile=altmob,
                                      paddress=paddress,
                                      caddress=caddress,
                                      dob=dob, photo=photo, occupation=occupation, office_address=off_add,
                                      branch=branch,
                                      con_person_name=cpname,
                                      off_email=offemail, designation=design, website=website, company_type=com_type,
                                      case_type=case_types, new_type=new_type,case_nature=case_natures, new_nature=new_nature,
                                      reference=refer,new_reference=new_refer, refer_client=referclient, refer_agent=referagent,
                                      acommision=agent_com, remark=remark)
            kyc_pending_save.save()
            messages.add_message(request, messages.INFO, 'Data is Move to Kyc Pending...!!!')
            return redirect('/kyc_pending')

        elif request.POST["save"] == 'proceed':

            legal_db_save = legal_pending_db(client_code=client_code,e_code=ecode,off_branch=off_branch, client_name=client_name, father_name=father_name,
                                      mother_name=mother_name, gender=gender,
                                      marriage=marriage,
                                      client_type=clienttype, email=email, mobile=mob, alt_mobile=altmob,
                                      paddress=paddress,
                                      caddress=caddress,
                                      dob=dob, photo=photo, occupation=occupation, office_address=off_add,
                                      branch=branch,
                                      con_person_name=cpname,
                                      off_email=offemail, designation=design, website=website, company_type=com_type,
                                      case_type=case_types, new_type=new_type,case_nature=case_natures, new_nature=new_nature,
                                      reference=refer,new_reference=new_refer, refer_client=referclient, refer_agent=referagent,
                                      acommision=agent_com, remark=remark)
            legal_db_save.save()
            messages.add_message(request, messages.INFO, 'Data is Move to Legal ...!!!')
            return redirect('/sales_view')

        return redirect('/kyc_add.html')
    clnt = sale.objects.all()
    agnt = agent_db.objects.all()
    case = case_type.objects.all()
    return render(request,'kyc_add.html',{'x':x,'xx':case, 'clnt': clnt, 'agnt': agnt})


#================================================Kyc list=================================================================
@login_required()
@csrf_exempt
def kyc_list(request):
    x=kyc_db.objects.all()
    return render(request,'kyc_list.html',{'x':x})

#================================================Kyc pending list=================================================================
@login_required()
@csrf_exempt
def kyc_pending_list(request):
    x=kyc_pending.objects.all()
    return render(request,'kyc_pending.html',{'x':x})

#================================================Kyc Edit=================================================================
@login_required()
@csrf_exempt
def kyc_edit(request,id):
    x=kyc_db.objects.get(id=id)
    clnt = sale.objects.all()
    agnt = agent_db.objects.all()
    branch_d=branch_db.objects.all()
    case = case_type.objects.all()

    return render(request,'kyc_edit.html',{'x':x,'xx':case, 'clnt': clnt, 'agnt': agnt,'branch':branch_d})

#================================================Kyc Edit=================================================================
@login_required()
@csrf_exempt
def kyc_update(request,id):
    x=kyc_db.objects.get(id=id)
    if request.method=='POST':
        client_code=x.client_code
        x.ecode = request.POST["ecode"]
        x.client_name = request.POST["cname"]
        x.branch = request.POST["mbranch"]
        x.father_name = request.POST["fname"]
        x.mother_name = request.POST["mname"]
        x.gender = request.POST["gender"]
        x.marriage = request.POST["marriage"]
        x.clienttype = request.POST["clienttype"]
        x.email = request.POST["email"]
        x.mob = request.POST["mob"]
        x.alt_mob = request.POST["altmob"]
        x.paddress = request.POST["padd"]
        x.caddress = request.POST["cadd"]
        x.dob = request.POST["dob"]
        x.occupation = request.POST["occ"]
        x.office_address = request.POST["offadd"]
        x.off_branch = request.POST["branch"]
        x.con_person_pname = request.POST["cpname"]
        x.off_email = request.POST["offemail"]
        x.designation = request.POST["des"]
        x.website = request.POST["web"]
        x.company_type = request.POST["comtype"]
        if request.POST['casetype'] == 'othertype':
            x.case_type = request.POST["casetype"]
            x.new_type = request.POST["ncase"]
        else:
            x.case_type = request.POST["casetype"]
            x.new_type = 'Null'
        if request.POST['casenature'] == 'othernature':
            x.case_nature = request.POST["casenature"]
            x.new_nature = request.POST["nnature"]
        else:
            x.case_nature = request.POST["casenature"]
            x.new_nature = "Null"
        if request.POST["refer"] == 'Direct' or 'Telecall':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        if request.POST['refer'] == 'Via_Client':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = request.POST["rclient"]
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        if request.POST['refer'] == 'Via_Agent':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = request.POST["ragent"]
            x.acommision = request.POST["acom"]
        if request.POST['refer'] == 'otherrefer':
            x.reference = request.POST["refer"]
            x.new_reference = request.POST['nrefer']
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        x.remark = request.POST["remark"]
        try:
            x.photo = request.FILES["photo"]
            x.save()
        except MultiValueDictKeyError:
            pass

        if request.POST['save'] == 'close':
            x.save()
            messages.add_message(request, messages.INFO, 'Data Updated...!!!')
            return redirect('/kyc_list')

        if request.POST['save'] == 'pending':
            ecode = request.POST["ecode"]
            client_name = request.POST["cname"]
            branch= request.POST["mbranch"]
            father_name = request.POST["fname"]
            mother_name = request.POST["mname"]
            gender = request.POST["gender"]
            marriage = request.POST["marriage"]
            clienttype = request.POST["clienttype"]
            email = request.POST["email"]
            mob = request.POST["mob"]
            altmob = request.POST["altmob"]
            paddress = request.POST["padd"]
            caddress = request.POST["cadd"]
            dob = request.POST["dob"]
            try:
                photo = request.FILES["photo"]
            except MultiValueDictKeyError:
                photo = x.photo
            occupation = request.POST["occ"]
            off_add = request.POST["offadd"]
            off_branch = request.POST["branch"]
            cpname = request.POST["cpname"]
            offemail = request.POST["offemail"]
            design = request.POST["des"]
            website = request.POST["web"]
            com_type = request.POST["comtype"]
            case_types = request.POST["casetype"]
            new_type = request.POST["ncase"]
            case_natures = request.POST["casenature"]
            new_nature = request.POST["nnature"]
            refer = request.POST["refer"]
            new_refer = request.POST["nrefer"]
            referclient = request.POST["rclient"]
            referagent = request.POST["ragent"]
            agent_com = request.POST["acom"]
            remark = request.POST["remark"]
            client_code=x.client_code

            kyc_pending_save = kyc_pending(client_code=client_code,e_code=ecode, client_name=client_name,off_branch=off_branch, father_name=father_name,
                              mother_name=mother_name, gender=gender,
                              marriage=marriage,
                              client_type=clienttype, email=email, mobile=mob, alt_mobile=altmob, paddress=paddress,
                              caddress=caddress,
                              dob=dob, photo=photo, occupation=occupation, office_address=off_add, branch=branch,
                              con_person_name=cpname,
                              off_email=offemail, designation=design, website=website, company_type=com_type,
                              case_type=case_types, new_type=new_type,case_nature=case_natures, new_nature=new_nature,
                              reference=refer,new_reference=new_refer, refer_client=referclient, refer_agent=referagent,
                              acommision=agent_com, remark=remark)
            kyc_pending_save.save()
            x.save()
            messages.add_message(request, messages.INFO, 'Data is Move to Pending...!!!')
            return redirect('/kyc_pending')

        elif request.POST['save'] == 'proceed':
            ecode = request.POST["ecode"]
            client_name = request.POST["cname"]
            branch= request.POST["mbranch"]
            father_name = request.POST["fname"]
            mother_name = request.POST["mname"]
            gender = request.POST["gender"]
            marriage = request.POST["marriage"]
            clienttype = request.POST["clienttype"]
            email = request.POST["email"]
            mob = request.POST["mob"]
            altmob = request.POST["altmob"]
            paddress = request.POST["padd"]
            caddress = request.POST["cadd"]
            dob = request.POST["dob"]
            try:
                photo = request.FILES["photo"]
            except MultiValueDictKeyError:
                photo = x.photo
            occupation = request.POST["occ"]
            off_add = request.POST["offadd"]
            off_branch = request.POST["branch"]
            cpname = request.POST["cpname"]
            offemail = request.POST["offemail"]
            design = request.POST["des"]
            website = request.POST["web"]
            com_type = request.POST["comtype"]
            case_types = request.POST["casetype"]
            new_type = request.POST["ncase"]
            case_natures = request.POST["casenature"]
            new_nature = request.POST["nnature"]
            refer = request.POST["refer"]
            new_refer = request.POST["nrefer"]
            referclient = request.POST["rclient"]
            referagent = request.POST["ragent"]
            agent_com = request.POST["acom"]
            remark = request.POST["remark"]

            legal_db_save = legal_pending_db(client_code=client_code,e_code=ecode, client_name=client_name,off_branch=off_branch, father_name=father_name,
                              mother_name=mother_name, gender=gender,
                              marriage=marriage,
                              client_type=clienttype, email=email, mobile=mob, alt_mobile=altmob, paddress=paddress,
                              caddress=caddress,
                              dob=dob, photo=photo, occupation=occupation, office_address=off_add, branch=branch,
                              con_person_name=cpname,
                              off_email=offemail, designation=design, website=website, company_type=com_type,
                              case_type=case_types, new_type=new_type,case_nature=case_natures, new_nature=new_nature,
                              reference=refer,new_reference=new_refer, refer_client=referclient, refer_agent=referagent,
                              acommision=agent_com, remark=remark)
            legal_db_save.save()
            x.save()
            messages.add_message(request, messages.INFO, 'Data is Move to Legal...!!!')
            return redirect('/sales_view')

        return redirect('/kyc_list')
    return redirect('/kyc_list')

#================================================Kyc pending Edit=================================================================
@login_required()
@csrf_exempt
def kyc_p_edit(request,id):
    x=kyc_pending.objects.get(id=id)
    clnt = sale.objects.all()
    agnt = agent_db.objects.all()
    branch_d=branch_db.objects.all()
    case = case_type.objects.all()

    return render(request,'kyc_pend_edit.html',{'x':x,'xx':case, 'clnt': clnt, 'agnt': agnt,'branch':branch_d})
#================================================Kyc pending Edit=================================================================
@login_required()
@csrf_exempt
def kyc_p_update(request,id):
    x=kyc_pending.objects.get(id=id)
    if request.method=='POST':
        client_code=x.client_code
        x.ecode = request.POST["ecode"]
        x.client_name = request.POST["cname"]
        x.branch= request.POST["mbranch"]
        x.father_name = request.POST["fname"]
        x.mother_name = request.POST["mname"]
        x.gender = request.POST["gender"]
        x.marriage = request.POST["marriage"]
        x.clienttype = request.POST["clienttype"]
        x.email = request.POST["email"]
        x.mob = request.POST["mob"]
        x.alt_mob = request.POST["altmob"]
        x.paddress = request.POST["padd"]
        x.caddress = request.POST["cadd"]
        x.dob = request.POST["dob"]
        x.occupation = request.POST["occ"]
        x.office_address = request.POST["offadd"]
        x.off_branch = request.POST["branch"]
        x.con_person_pname = request.POST["cpname"]
        x.off_email = request.POST["offemail"]
        x.designation = request.POST["des"]
        x.website = request.POST["web"]
        x.company_type = request.POST["comtype"]
        if request.POST['casetype'] == 'othertype':
            x.case_type = request.POST["casetype"]
            x.new_type = request.POST["ncase"]
        else:
            x.case_type = request.POST["casetype"]
            x.new_type = 'Null'
        if request.POST['casenature'] == 'othernature':
            x.case_nature = request.POST["casenature"]
            x.new_nature = request.POST["nnature"]
        else:
            x.case_nature = request.POST["casenature"]
            x.new_nature = "Null"
        if request.POST["refer"] == 'Direct' or 'Telecall':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        if request.POST['refer'] == 'Via_Client':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = request.POST["rclient"]
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        if request.POST['refer'] == 'Via_Agent':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = request.POST["ragent"]
            x.acommision = request.POST["acom"]
        if request.POST['refer'] == 'otherrefer':
            x.reference = request.POST["refer"]
            x.new_reference = request.POST['nrefer']
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        x.remark = request.POST["remark"]
        try:
            x.photo = request.FILES["photo"]
            x.save()
        except MultiValueDictKeyError:
            pass

        if request.POST['save'] == 'back':
            return redirect('/kyc_pending')

        elif request.POST['save'] == 'update':
            x.save()
            messages.add_message(request, messages.INFO, 'Data Updated...!!!')
            return redirect('/kyc_pending')

        if request.POST['save'] == 'proceed':
            ecode = request.POST["ecode"]
            client_name = request.POST["cname"]
            branch= request.POST["mbranch"]
            father_name = request.POST["fname"]
            mother_name = request.POST["mname"]
            gender = request.POST["gender"]
            marriage = request.POST["marriage"]
            clienttype = request.POST["clienttype"]
            email = request.POST["email"]
            mob = request.POST["mob"]
            altmob = request.POST["altmob"]
            paddress = request.POST["padd"]
            caddress = request.POST["cadd"]
            dob = request.POST["dob"]
            try:
                photo = request.FILES["photo"]
            except MultiValueDictKeyError:
                photo = x.photo
            occupation = request.POST["occ"]
            off_add = request.POST["offadd"]
            off_branch = request.POST["branch"]
            cpname = request.POST["cpname"]
            offemail = request.POST["offemail"]
            design = request.POST["des"]
            website = request.POST["web"]
            com_type = request.POST["comtype"]
            case_types = request.POST["casetype"]
            new_type = request.POST["ncase"]
            case_natures = request.POST["casenature"]
            new_nature = request.POST["nnature"]
            refer = request.POST["refer"]
            new_refer = request.POST["nrefer"]
            referclient = request.POST["rclient"]
            referagent = request.POST["ragent"]
            agent_com = request.POST["acom"]
            remark = request.POST["remark"]



            legal_db_save = legal_pending_db(client_code=client_code,e_code=ecode, client_name=client_name,off_branch=off_branch, father_name=father_name,
                              mother_name=mother_name, gender=gender,
                              marriage=marriage,
                              client_type=clienttype, email=email, mobile=mob, alt_mobile=altmob, paddress=paddress,
                              caddress=caddress,
                              dob=dob, photo=photo, occupation=occupation, office_address=off_add, branch=branch,
                              con_person_name=cpname,
                              off_email=offemail, designation=design, website=website, company_type=com_type,
                              case_type=case_types, new_type=new_type,case_nature=case_natures, new_nature=new_nature,
                              reference=refer,new_reference=new_refer, refer_client=referclient, refer_agent=referagent,
                              acommision=agent_com, remark=remark)
            legal_db_save.save()
            x.delete()
            messages.add_message(request, messages.INFO, 'Data is Move to Legal...!!!')
            return redirect('/sales_view')


        return redirect('/kyc_list')
    return redirect('/kyc_list')

#================================================Agent Add=================================================================
@login_required()
@csrf_exempt
def agent_add(request):
    agent_len=agent_db.objects.all()
    a_code='SLBAG{}0{}'.format(datetime.datetime.now().strftime('%y%m'),(len(agent_len)+1))
    if request.method=='POST':
        a_code = request.POST["acode"]
        agent_name = request.POST["cname"]
        father_name = request.POST["fname"]
        mother_name = request.POST["mname"]
        gender = request.POST["gender"]
        marriage = request.POST["marriage"]
        email = request.POST["email"]
        mob = request.POST["mob"]
        altmob = request.POST["altmob"]
        paddress = request.POST["padd"]
        caddress = request.POST["cadd"]
        dob = request.POST["dob"]
        try:
            photo = request.FILES["photo"]
        except MultiValueDictKeyError:
            photo = ''
        occupation = request.POST["occ"]
        agent_com = request.POST["acom"]
        remark = request.POST["remark"]

        agent_db_save = agent_db(agent_code=a_code, agent_name=agent_name, father_name=father_name,
                                 mother_name=mother_name, gender=gender,marriage=marriage,email=email, mobile=mob, alt_mobile=altmob,
                                 paddress=paddress,caddress=caddress,dob=dob, photo=photo, occupation=occupation,
                                 acommision=agent_com, remark=remark)
        agent_db_save.save()
        messages.add_message(request, messages.INFO, 'Agent Added...!!!')
        return redirect('/agent_list')

    return render(request,'agent_add.html',{'x':a_code})

#================================================Agent list=================================================================
@login_required()
@csrf_exempt
def agent_list(request):
    x=agent_db.objects.all()
    return render(request,'agent_list.html',{'x':x})

#================================================Agent Edit=================================================================
@login_required()
@csrf_exempt
def agent_edit(request,id):
    x=agent_db.objects.get(id=id)
    return render(request,'agent_edit.html',{'x':x})

#================================================Agent Edit=================================================================
@login_required()
@csrf_exempt
def agent_update(request,id):
    x=agent_db.objects.get(id=id)
    if request.method=='POST':
        if request.method == 'POST':
            x.agent_code = request.POST["acode"]
            x.agent_name = request.POST["aname"]
            x.father_name = request.POST["fname"]
            x.mother_name = request.POST["mname"]
            x.gender = request.POST["gender"]
            x.marriage = request.POST["marriage"]
            x.email = request.POST["email"]
            x.mob = request.POST["mob"]
            x.alt_mob = request.POST["altmob"]
            x.paddress = request.POST["padd"]
            x.caddress = request.POST["cadd"]
            x.dob = request.POST["dob"]
            x.occupation = request.POST["occ"]
            x.remark = request.POST["remark"]
            x.acommision= request.POST["acom"]

            try:
                x.photo = request.FILES["photo"]
                x.save()
            except MultiValueDictKeyError:
                x.photo=x.photo
                x.save()
            messages.add_message(request, messages.INFO, 'Data Updated...!!!')
            return redirect('/agent_list')
    return redirect('/agent_list')


#================================================Branch Add=================================================================
@login_required()
@csrf_exempt
def branch_add(request):
    data = branch_db.objects.all()
    if request.method=="POST":
        x=branch_db.objects.create(branch=request.POST["branch"])
        messages.add_message(request, messages.INFO, 'New Branch Added...!!!')
        return redirect('/branch_add')
    return render(request,'branch_add.html',{'data':data})

#================================================Branch delete=================================================================
@login_required()
@csrf_exempt
def branch_delete(request,id):
    data = branch_db.objects.get(id=id)
    data.delete()
    return redirect('/branch_add')

#================================================finance list=================================================================
@login_required()
@csrf_exempt
def finance_list(request):
    x=finance_db.objects.all()
    return render(request,'finance_sale_list.html',{'x':x})

#================================================finance Edit=================================================================
@login_required()
@csrf_exempt
def finance_edit(request,id):
    x=finance_db.objects.get(id=id)
    agnt=agent_db.objects.all()
    return render(request,'finance_edit.html',{'x':x,'agnt':agnt})

#================================================finance Update=================================================================
@login_required()
@csrf_exempt
def finance_update(request,id):
    x=finance_db.objects.get(id=id)
    if request.method=='POST':
        code=request.POST['ccode']
        x.declared=request.POST["damount"]
        x.received=request.POST["ramount"]
        x.pending=request.POST["pamount"]
        x.paid_status=request.POST["status"]
        x.save()

        status=sale.objects.filter(client_code__exact=code).get()
        status.paid_status=x.paid_status
        status.save()
        messages.add_message(request, messages.INFO, 'Finance Updated...!!!')
        return redirect('finance_list')

    return render(request,'finance_sale_list.html')


#================================================Legal pendng list=================================================================
@login_required()
@csrf_exempt
def legal_pending_list(request):
    x=legal_pending_db.objects.all()
    return render(request,'legal_pending_list.html',{'x':x})

#================================================Legal pending edit=================================================================
@login_required()
@csrf_exempt
def legal_pending_edit(request,id):
    x=legal_pending_db.objects.get(id=id)
    panel=users.objects.filter(staff_type__contains='Panel')
    asso=users.objects.filter(staff_type__contains='Associate')
    court=court_db.objects.all()
    clnt = sale.objects.all()
    agnt = agent_db.objects.all()
    branch_d = branch_db.objects.all()
    case = case_type.objects.all()

    return render(request,'legal_pending_edit.html',{'x':x,'panel':panel,'asso':asso,'court':court, 'clnt': clnt, 'agnt': agnt,
                                                     'xx':case,'branch': branch_d})

#================================================Legal_pending update=================================================================
@login_required()
@csrf_exempt
def legal_pending_update(request,id):
    x = legal_pending_db.objects.get(id=id)
    if request.method == 'POST':
        x.ecode = request.POST["ecode"]
        x.client_name = request.POST["cname"]
        x.branch = request.POST["mbranch"]
        x.father_name = request.POST["fname"]
        x.mother_name = request.POST["mname"]
        x.gender = request.POST["gender"]
        x.marriage = request.POST["marriage"]
        x.clienttype = request.POST["clienttype"]
        x.email = request.POST["email"]
        x.mob = request.POST["mob"]
        x.alt_mob = request.POST["altmob"]
        x.paddress = request.POST["padd"]
        x.caddress = request.POST["cadd"]
        x.dob = request.POST["dob"]
        x.occupation = request.POST["occ"]
        x.office_address = request.POST["offadd"]
        x.off_branch = request.POST["branch"]
        x.con_person_pname = request.POST["cpname"]
        x.off_email = request.POST["offemail"]
        x.designation = request.POST["des"]
        x.website = request.POST["web"]
        x.company_type = request.POST["comtype"]
        if request.POST['casetype'] == 'othertype':
            x.case_type = request.POST["casetype"]
            x.new_type = request.POST["ncase"]
        else:
            x.case_type = request.POST["casetype"]
            x.new_type = 'Null'
        if request.POST['casenature'] == 'othernature':
            x.case_nature = request.POST["casenature"]
            x.new_nature = request.POST["nnature"]
        else:
            x.case_nature = request.POST["casenature"]
            x.new_nature = "Null"
        if request.POST["refer"] == 'Direct' or 'Telecall':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        if request.POST['refer'] == 'Via_Client':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = request.POST["rclient"]
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        if request.POST['refer'] == 'Via_Agent':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = request.POST["ragent"]
            x.acommision = request.POST["acom"]
        if request.POST['refer'] == 'otherrefer':
            x.reference = request.POST["refer"]
            x.new_reference = request.POST['nrefer']
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        x.remark = request.POST["remark"]
        if request.POST['cln'] != 'Null':
            x.court_location = request.POST["cln"]
        else:
            x.court_location = request.POST["ncln"]
        if request.POST['ccs'] != 'Null':
            x.court_campus= request.POST["ccs"]
        else:
            x.court_campus=request.POST['nccs']
        x.panel=request.POST['panel']
        x.associate=request.POST['asso']
        x.allocated=request.POST['allocate']
        try:
            x.photo = request.FILES["photo"]
            x.save()
        except MultiValueDictKeyError:
            pass
        new=court_db.objects.create(court_location=request.POST["ncln"],court_campus=request.POST["nccs"])
        #============================================================================================
        ecode = request.POST["ecode"]
        client_name = request.POST["cname"]
        branch = request.POST["mbranch"]
        father_name = request.POST["fname"]
        mother_name = request.POST["mname"]
        gender = request.POST["gender"]
        marriage = request.POST["marriage"]
        clienttype = request.POST["clienttype"]
        email = request.POST["email"]
        mob = request.POST["mob"]
        altmob = request.POST["altmob"]
        paddress = request.POST["padd"]
        caddress = request.POST["cadd"]
        dob = request.POST["dob"]
        try:
            photo = request.FILES["photo"]
        except MultiValueDictKeyError:
            photo = x.photo
        occupation = request.POST["occ"]
        off_add = request.POST["offadd"]
        off_branch = request.POST["branch"]
        cpname = request.POST["cpname"]
        offemail = request.POST["offemail"]
        design = request.POST["des"]
        website = request.POST["web"]
        com_type = request.POST["comtype"]
        case_types = request.POST["casetype"]
        new_type = request.POST["ncase"]
        case_natures = request.POST["casenature"]
        new_nature = request.POST["nnature"]
        refer = request.POST["refer"]
        new_refer = request.POST["nrefer"]
        referclient = request.POST["rclient"]
        referagent = request.POST["ragent"]
        agent_com = request.POST["acom"]
        remark = request.POST["remark"]
        if request.POST['cln'] != 'Null':
            court_location = request.POST["cln"]
        else:
            court_location = request.POST["ncln"]
        if request.POST['ccs'] != 'Null':
            court_campus= request.POST["ccs"]
        else:
            court_campus=request.POST['nccs']
        allocated=request.POST["allocate"]
        panel = request.POST['panel']
        associate = request.POST['asso']
        #============================================================================================
        if request.POST['save'] == 'close':

            legal_db_save = legal_closed_db(client_code=x.client_code, e_code=ecode,
                                            client_name=client_name, off_branch=off_branch, father_name=father_name,
                                            mother_name=mother_name, gender=gender,marriage=marriage,
                                            client_type=clienttype, email=email, mobile=mob, alt_mobile=altmob,paddress=paddress,
                                            caddress=caddress,dob=dob, photo=photo, occupation=occupation, office_address=off_add,
                                            branch=branch,con_person_name=cpname,
                                            off_email=offemail, designation=design, website=website,company_type=com_type,
                                            case_type=case_types, new_type=new_type, case_nature=case_natures,
                                            new_nature=new_nature,
                                            reference=refer,new_reference=new_refer, refer_client=referclient, refer_agent=referagent,
                                            acommision=agent_com, remark=remark,court_location=court_location,court_campus=court_campus,
                                            allocated=allocated,panel=panel,associate=associate)
            legal_db_save.save()
            x.delete()
            messages.add_message(request, messages.INFO, 'Data is Closed...!!!')
            return redirect('/legal_pending_list')
        elif request.POST['save'] == 'update':
            x.save()
            messages.add_message(request, messages.INFO, 'Data Updated...!!!')
            return redirect('/legal_pending_list')
        elif request.POST['save'] == 'proceed':
            legal_count = job_count.objects.all()
            jcode = 'SLBJC{}0{}'.format(datetime.datetime.now().strftime('%y%m'), (len(legal_count) + 1))
            job=job_count.objects.create(job=jcode)
            legal_db_save = legal_db(client_code=x.client_code, e_code=ecode,job_code=jcode,
                                            client_name=client_name, off_branch=off_branch, father_name=father_name,
                                            mother_name=mother_name, gender=gender,
                                            marriage=marriage,
                                            client_type=clienttype, email=email, mobile=mob, alt_mobile=altmob,
                                            paddress=paddress,
                                            caddress=caddress,
                                            dob=dob, photo=photo, occupation=occupation, office_address=off_add,
                                            branch=branch,
                                            con_person_name=cpname,
                                            off_email=offemail, designation=design, website=website,
                                            company_type=com_type,
                                            reference=refer,
                                            case_type=case_types, new_type=new_type, case_nature=case_natures,
                                            new_nature=new_nature,
                                            new_reference=new_refer, refer_client=referclient, refer_agent=referagent,
                                            acommision=agent_com, remark=remark,court_location=court_location,court_campus=court_campus,
                                     allocated=allocated,panel=panel,associate=associate)
            x.delete()
            legal_db_save.save()
            messages.add_message(request, messages.INFO, 'Data is Move to Legal...!!!')
            return redirect('/legal_list')

    return redirect('/legal_list')


#================================================Legal list=================================================================
@login_required()
@csrf_exempt
def legal_list(request):
    x=legal_db.objects.all()
    return render(request,'legal_list.html',{'x':x})

#================================================Legal edit=================================================================
@login_required()
@csrf_exempt
def legal_edit(request,id):
    x=legal_db.objects.get(id=id)
    panel=users.objects.filter(staff_type__contains='Panel')
    asso=users.objects.filter(staff_type__contains='Associate')
    court=court_db.objects.all()
    clnt = sale.objects.all()
    agnt = agent_db.objects.all()
    branch_d = branch_db.objects.all()
    case = case_type.objects.all()

    return render(request,'legal_edit.html',{'x':x,'panel':panel,'asso':asso,'court':court, 'clnt': clnt,
                                             'xx':case,'agnt': agnt, 'branch': branch_d})

#================================================Legal_update=================================================================
@login_required()
@csrf_exempt
def legal_update(request,id):
    x = legal_db.objects.get(id=id)
    if request.method == 'POST':
        x.ecode = request.POST["ecode"]
        x.client_name = request.POST["cname"]
        x.branch = request.POST["mbranch"]
        x.father_name = request.POST["fname"]
        x.mother_name = request.POST["mname"]
        x.gender = request.POST["gender"]
        x.marriage = request.POST["marriage"]
        x.clienttype = request.POST["clienttype"]
        x.email = request.POST["email"]
        x.mob = request.POST["mob"]
        x.alt_mob = request.POST["altmob"]
        x.paddress = request.POST["padd"]
        x.caddress = request.POST["cadd"]
        x.dob = request.POST["dob"]
        x.occupation = request.POST["occ"]
        x.office_address = request.POST["offadd"]
        x.off_branch = request.POST["branch"]
        x.con_person_pname = request.POST["cpname"]
        x.off_email = request.POST["offemail"]
        x.designation = request.POST["des"]
        x.website = request.POST["web"]
        x.company_type = request.POST["comtype"]
        if request.POST['casetype'] == 'othertype':
            x.case_type = request.POST["casetype"]
            x.new_type = request.POST["ncase"]
        else:
            x.case_type = request.POST["casetype"]
            x.new_type = 'Null'
        if request.POST['casenature'] == 'othernature':
            x.case_nature = request.POST["casenature"]
            x.new_nature = request.POST["nnature"]
        else:
            x.case_nature = request.POST["casenature"]
            x.new_nature = "Null"
        if request.POST["refer"] == 'Direct' or 'Telecall':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        if request.POST['refer'] == 'Via_Client':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = request.POST["rclient"]
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        if request.POST['refer'] == 'Via_Agent':
            x.reference = request.POST["refer"]
            x.new_reference = 'Null'
            x.refer_client = 'Null'
            x.refer_agent = request.POST["ragent"]
            x.acommision = request.POST["acom"]
        if request.POST['refer'] == 'otherrefer':
            x.reference = request.POST["refer"]
            x.new_reference = request.POST['nrefer']
            x.refer_client = 'Null'
            x.refer_agent = 'Null'
            x.acommision = 'Null'
        x.remark = request.POST["remark"]
        if request.POST['cln'] != 'Null':
            x.court_location = request.POST["cln"]
        else:
            x.court_location = request.POST["ncln"]
        if request.POST['ccs'] != 'Null':
            x.court_campus = request.POST["ccs"]
        else:
            x.court_campus = request.POST['nccs']
        x.panel = request.POST['panel']
        x.associate = request.POST['asso']
        x.allocated = request.POST['allocate']
        try:
            x.photo = request.FILES["photo"]
            x.save()
        except MultiValueDictKeyError:
            pass

    # ============================================================================================
        ecode = request.POST["ecode"]
        client_name = request.POST["cname"]
        branch = request.POST["mbranch"]
        father_name = request.POST["fname"]
        mother_name = request.POST["mname"]
        gender = request.POST["gender"]
        marriage = request.POST["marriage"]
        clienttype = request.POST["clienttype"]
        email = request.POST["email"]
        mob = request.POST["mob"]
        altmob = request.POST["altmob"]
        paddress = request.POST["padd"]
        caddress = request.POST["cadd"]
        dob = request.POST["dob"]
        try:
            photo = request.FILES["photo"]
        except MultiValueDictKeyError:
            photo = x.photo
        occupation = request.POST["occ"]
        off_add = request.POST["offadd"]
        off_branch = request.POST["branch"]
        cpname = request.POST["cpname"]
        offemail = request.POST["offemail"]
        design = request.POST["des"]
        website = request.POST["web"]
        com_type = request.POST["comtype"]
        refer = request.POST["refer"]
        case_types = request.POST["casetype"]
        new_type = request.POST["ncase"]
        case_natures = request.POST["casenature"]
        new_nature = request.POST["nnature"]
        new_refer = request.POST["nrefer"]
        referclient = request.POST["rclient"]
        referagent = request.POST["ragent"]
        agent_com = request.POST["acom"]
        remark = request.POST["remark"]
        if request.POST['cln'] != 'Null':
            court_location = request.POST["cln"]
        else:
            court_location = request.POST["ncln"]
        if request.POST['ccs'] != 'Null':
            court_campus = request.POST["ccs"]
        else:
            court_campus = request.POST['nccs']
        allocated = request.POST["allocate"]
        panel = request.POST['panel']
        associate = request.POST['asso']
    # ============================================================================================
        loc=court_db.objects.filter(court_location__contains=request.POST['ncln'])
        cam=court_db.objects.filter(court_campus__contains=request.POST['nccs'])
        if loc:
            pass
        else:
            new=court_db.objects.create(court_location=request.POST["ncln"])
        if cam:
            pass
        else:
            new = court_db.objects.create(court_campus=["nccs"])

    # ============================================================================================
        if request.POST['save'] == 'update':
            x.save()
            messages.add_message(request, messages.INFO, 'Data Updated...!!!')
            return redirect('/legal_list')
        if request.POST['save'] == 'close':
            legal_db_save = legal_closed_db(client_code=x.client_code, e_code=ecode,
                                            client_name=client_name, off_branch=off_branch, father_name=father_name,
                                            mother_name=mother_name, gender=gender, marriage=marriage,
                                            client_type=clienttype, email=email, mobile=mob, alt_mobile=altmob,
                                            paddress=paddress,
                                            caddress=caddress, dob=dob, photo=photo, occupation=occupation,
                                            office_address=off_add,
                                            branch=branch, con_person_name=cpname,
                                            off_email=offemail, designation=design, website=website,
                                            company_type=com_type,case_type=case_types, new_type=new_type,
                                            case_nature=case_natures, new_nature=new_nature,
                                            reference=refer, new_reference=new_refer, refer_client=referclient,
                                            refer_agent=referagent,
                                            acommision=agent_com, remark=remark, court_location=court_location,
                                            court_campus=court_campus,
                                            allocated=allocated, panel=panel, associate=associate)
            legal_db_save.save()
            x.delete()
            messages.add_message(request, messages.INFO, 'Data is Closed...!!!')
            return redirect('/legal_list')
        if request.POST['save'] == 'pending':
            legal_db_save = legal_pending_db(client_code=x.client_code, e_code=ecode,
                                            client_name=client_name, off_branch=off_branch, father_name=father_name,
                                            mother_name=mother_name, gender=gender, marriage=marriage,
                                            client_type=clienttype, email=email, mobile=mob, alt_mobile=altmob,
                                            paddress=paddress,
                                            caddress=caddress, dob=dob, photo=photo, occupation=occupation,
                                            office_address=off_add,
                                            branch=branch, con_person_name=cpname,
                                            off_email=offemail, designation=design, website=website,
                                            company_type=com_type,case_type=case_types, new_type=new_type,
                                            case_nature=case_natures, new_nature=new_nature,
                                            reference=refer, new_reference=new_refer, refer_client=referclient,
                                            refer_agent=referagent,
                                            acommision=agent_com, remark=remark, court_location=court_location,
                                            court_campus=court_campus,
                                            allocated=allocated, panel=panel, associate=associate)
            legal_db_save.save()
            messages.add_message(request, messages.INFO, 'Data is Move to Pending...!!!')
            return redirect('/legal_pending_list')

        if request.POST['save'] == 'proceed':
            if x.case_type == 'othertype':
                case=x.new_type
            else:
                case=x.case_type
            notice_db_save = notice_db(e_code=x.e_code,client_code=x.client_code,job_code=x.job_code,client_name=x.client_name,
                                       branch=x.branch,case_type=case)
            notice_db_save.save()
            messages.add_message(request, messages.INFO, 'Data is Move to Notice...!!!')
            return redirect('/notice_list')
    return redirect('/legal_list')

#================================================Notice List=============================================
@csrf_exempt
@login_required()
def notice_list(request):
    x=notice_db.objects.all()
    return render(request,'notice_list.html',{'x':x})

#================================================Notice Edit=============================================
@csrf_exempt
@login_required()
def notice_edit(request,id):
    x=notice_db.objects.get(id=id)
    return render(request,'notice.html',{'x':x})

#================================================Notice update=============================================
@csrf_exempt
@login_required()
def notice_update(request,id):
    x=notice_db.objects.get(id=id)
    if request.method == 'POST':
        x.notice_date1 = request.POST['date1']
        x.description1 = request.POST['des1']
        x.notice_date2 = request.POST['date2']
        x.description2 = request.POST['des2']
        x.notice_date3 = request.POST['date3']
        x.description3 = request.POST['des3']
        x.remark       = request.POST['remark']
        date = request.POST["date1"]
        # date += datetime.timedelta(days=60)
        print('==========================================',datetime.datetime.now())
        print('==========================================',date)

    return redirect('/notice_list')

#================================================Notice update=============================================
