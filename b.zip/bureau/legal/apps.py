from django.apps import AppConfig


class LegalConfig(AppConfig):
    name = 'legal'
